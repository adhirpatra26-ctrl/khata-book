export type Lang = "en" | "hi" | "or";

export type TxType = "gave" | "received";

export type PaymentMethod = "cash" | "upi" | "bank" | "other" | "";

export interface Business {
  deviceId: string;
  businessName: string;
  ownerName: string;
  mobile: string;
  language: Lang;
}

export interface Customer {
  id: string;
  name: string;
  mobile: string;
  note: string;
  createdAt: number;
}

export interface Transaction {
  id: string;
  customerId: string;
  type: TxType;
  amount: number; // paise
  description: string;
  method: PaymentMethod;
  note: string;
  date: number; // epoch ms
  createdAt: number;
}
