"use client";

import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  ReactNode,
  useMemo,
} from "react";
import { Business, Customer, Transaction, Lang } from "./types";
import { getDict, Dict } from "./i18n";

const LS_BUSINESS = "hisabgo:business";
const LS_CUSTOMERS = "hisabgo:customers";
const LS_TX = "hisabgo:transactions";
const LS_PIN = "hisabgo:pin";
const LS_AUTOLOCK = "hisabgo:autolock";
const LS_ONBOARDED = "hisabgo:onboarded";

export function uid(): string {
  return (
    Date.now().toString(36) + Math.random().toString(36).slice(2, 10)
  );
}

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* ignore */
  }
}

interface StoreState {
  ready: boolean;
  business: Business | null;
  customers: Customer[];
  transactions: Transaction[];
  lang: Lang;
  d: Dict;
  hasPin: boolean;
  autoLock: boolean;
  onboarded: boolean;

  setLang: (l: Lang) => void;
  createBusiness: (b: { businessName: string; ownerName: string; mobile: string }) => void;
  updateBusiness: (b: Partial<Business>) => void;

  addCustomer: (c: { name: string; mobile: string; note?: string }) => Customer;
  updateCustomer: (id: string, c: Partial<Customer>) => void;
  deleteCustomer: (id: string) => void;

  addTransaction: (t: Omit<Transaction, "id" | "createdAt">) => void;
  deleteTransaction: (id: string) => void;

  balanceOf: (customerId: string) => number;
  transactionsOf: (customerId: string) => Transaction[];

  setPin: (pin: string) => void;
  removePin: () => void;
  checkPin: (pin: string) => boolean;
  setAutoLock: (v: boolean) => void;
  markOnboarded: () => void;

  exportJSON: () => string;
  importJSON: (raw: string) => boolean;
  resetAll: () => void;
}

const StoreContext = createContext<StoreState | null>(null);

async function syncToServer(
  business: Business,
  customers: Customer[],
  transactions: Transaction[]
) {
  try {
    await fetch("/api/sync", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ business, customers, transactions }),
    });
  } catch {
    // offline-first: ignore network errors
  }
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [business, setBusiness] = useState<Business | null>(null);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [lang, setLangState] = useState<Lang>("en");
  const [hasPin, setHasPin] = useState(false);
  const [autoLock, setAutoLockState] = useState(false);
  const [onboarded, setOnboarded] = useState(false);

  useEffect(() => {
    const b = read<Business | null>(LS_BUSINESS, null);
    setBusiness(b);
    if (b) setLangState(b.language);
    setCustomers(read<Customer[]>(LS_CUSTOMERS, []));
    setTransactions(read<Transaction[]>(LS_TX, []));
    setHasPin(!!read<string | null>(LS_PIN, null));
    setAutoLockState(read<boolean>(LS_AUTOLOCK, false));
    setOnboarded(read<boolean>(LS_ONBOARDED, false));
    setReady(true);
  }, []);

  const debouncedSync = useCallback(
    (b: Business | null, c: Customer[], t: Transaction[]) => {
      if (!b) return;
      syncToServer(b, c, t);
    },
    []
  );

  const d = useMemo(() => getDict(lang), [lang]);

  const persist = useCallback(
    (
      c: Customer[],
      t: Transaction[],
      b: Business | null = business
    ) => {
      write(LS_CUSTOMERS, c);
      write(LS_TX, t);
      if (b) write(LS_BUSINESS, b);
      debouncedSync(b, c, t);
    },
    [business, debouncedSync]
  );

  const setLang = useCallback(
    (l: Lang) => {
      setLangState(l);
      if (business) {
        const nb = { ...business, language: l };
        setBusiness(nb);
        write(LS_BUSINESS, nb);
        debouncedSync(nb, customers, transactions);
      }
    },
    [business, customers, transactions, debouncedSync]
  );

  const createBusiness = useCallback(
    (b: { businessName: string; ownerName: string; mobile: string }) => {
      const nb: Business = {
        deviceId: uid() + uid(),
        businessName: b.businessName.trim(),
        ownerName: b.ownerName.trim(),
        mobile: b.mobile.trim(),
        language: lang,
      };
      setBusiness(nb);
      write(LS_BUSINESS, nb);
      debouncedSync(nb, customers, transactions);
    },
    [lang, customers, transactions, debouncedSync]
  );

  const updateBusiness = useCallback(
    (b: Partial<Business>) => {
      if (!business) return;
      const nb = { ...business, ...b };
      setBusiness(nb);
      write(LS_BUSINESS, nb);
      debouncedSync(nb, customers, transactions);
    },
    [business, customers, transactions, debouncedSync]
  );

  const addCustomer = useCallback(
    (c: { name: string; mobile: string; note?: string }) => {
      const nc: Customer = {
        id: uid(),
        name: c.name.trim(),
        mobile: c.mobile.trim(),
        note: (c.note || "").trim(),
        createdAt: Date.now(),
      };
      const next = [nc, ...customers];
      setCustomers(next);
      persist(next, transactions);
      return nc;
    },
    [customers, transactions, persist]
  );

  const updateCustomer = useCallback(
    (id: string, c: Partial<Customer>) => {
      const next = customers.map((x) => (x.id === id ? { ...x, ...c } : x));
      setCustomers(next);
      persist(next, transactions);
    },
    [customers, transactions, persist]
  );

  const deleteCustomer = useCallback(
    (id: string) => {
      const nextC = customers.filter((x) => x.id !== id);
      const nextT = transactions.filter((x) => x.customerId !== id);
      setCustomers(nextC);
      setTransactions(nextT);
      persist(nextC, nextT);
    },
    [customers, transactions, persist]
  );

  const addTransaction = useCallback(
    (t: Omit<Transaction, "id" | "createdAt">) => {
      const nt: Transaction = { ...t, id: uid(), createdAt: Date.now() };
      const next = [nt, ...transactions];
      setTransactions(next);
      persist(customers, next);
    },
    [customers, transactions, persist]
  );

  const deleteTransaction = useCallback(
    (id: string) => {
      const next = transactions.filter((x) => x.id !== id);
      setTransactions(next);
      persist(customers, next);
    },
    [customers, transactions, persist]
  );

  const balanceOf = useCallback(
    (customerId: string) => {
      return transactions
        .filter((t) => t.customerId === customerId)
        .reduce(
          (acc, t) => acc + (t.type === "gave" ? t.amount : -t.amount),
          0
        );
    },
    [transactions]
  );

  const transactionsOf = useCallback(
    (customerId: string) => {
      return transactions
        .filter((t) => t.customerId === customerId)
        .sort((a, b) => a.date - b.date || a.createdAt - b.createdAt);
    },
    [transactions]
  );

  const setPin = useCallback((pin: string) => {
    write(LS_PIN, pin);
    setHasPin(true);
  }, []);

  const removePin = useCallback(() => {
    if (typeof window !== "undefined") localStorage.removeItem(LS_PIN);
    setHasPin(false);
  }, []);

  const checkPin = useCallback((pin: string) => {
    return read<string | null>(LS_PIN, null) === pin;
  }, []);

  const setAutoLock = useCallback((v: boolean) => {
    write(LS_AUTOLOCK, v);
    setAutoLockState(v);
  }, []);

  const markOnboarded = useCallback(() => {
    write(LS_ONBOARDED, true);
    setOnboarded(true);
  }, []);

  const exportJSON = useCallback(() => {
    return JSON.stringify(
      { business, customers, transactions, version: 1 },
      null,
      2
    );
  }, [business, customers, transactions]);

  const importJSON = useCallback(
    (raw: string) => {
      try {
        const parsed = JSON.parse(raw);
        if (!parsed || !Array.isArray(parsed.customers)) return false;
        const nc: Customer[] = parsed.customers;
        const nt: Transaction[] = Array.isArray(parsed.transactions)
          ? parsed.transactions
          : [];
        const nb: Business | null = parsed.business || business;
        setCustomers(nc);
        setTransactions(nt);
        if (nb) {
          setBusiness(nb);
          setLangState(nb.language || lang);
          write(LS_BUSINESS, nb);
        }
        write(LS_CUSTOMERS, nc);
        write(LS_TX, nt);
        debouncedSync(nb, nc, nt);
        return true;
      } catch {
        return false;
      }
    },
    [business, lang, debouncedSync]
  );

  const resetAll = useCallback(() => {
    if (typeof window !== "undefined") {
      [LS_BUSINESS, LS_CUSTOMERS, LS_TX, LS_PIN, LS_AUTOLOCK, LS_ONBOARDED].forEach(
        (k) => localStorage.removeItem(k)
      );
    }
    setBusiness(null);
    setCustomers([]);
    setTransactions([]);
    setHasPin(false);
    setAutoLockState(false);
    setOnboarded(false);
  }, []);

  const value: StoreState = {
    ready,
    business,
    customers,
    transactions,
    lang,
    d,
    hasPin,
    autoLock,
    onboarded,
    setLang,
    createBusiness,
    updateBusiness,
    addCustomer,
    updateCustomer,
    deleteCustomer,
    addTransaction,
    deleteTransaction,
    balanceOf,
    transactionsOf,
    setPin,
    removePin,
    checkPin,
    setAutoLock,
    markOnboarded,
    exportJSON,
    importJSON,
    resetAll,
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore(): StoreState {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}
