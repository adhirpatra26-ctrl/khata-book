import { Dict } from "./i18n";

// amounts are stored in paise (integer)
export function rupeesToPaise(v: string | number): number {
  const n = typeof v === "number" ? v : parseFloat(v.replace(/,/g, ""));
  if (isNaN(n)) return NaN;
  return Math.round(n * 100);
}

export function paiseToRupeesNumber(paise: number): number {
  return paise / 100;
}

// Indian number formatting with ₹
export function formatINR(paise: number, withSymbol = true): string {
  const rupees = paise / 100;
  const isNeg = rupees < 0;
  const abs = Math.abs(rupees);
  const fixed = Number.isInteger(abs) ? abs.toFixed(0) : abs.toFixed(2);
  const [intPart, decPart] = fixed.split(".");
  // Indian grouping
  let last3 = intPart.slice(-3);
  const rest = intPart.slice(0, -3);
  let grouped = last3;
  if (rest) {
    grouped = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + "," + last3;
  }
  const result = decPart ? `${grouped}.${decPart}` : grouped;
  return `${isNeg ? "-" : ""}${withSymbol ? "₹" : ""}${result}`;
}

export function formatDate(ms: number, d: Dict): string {
  const dt = new Date(ms);
  return `${dt.getDate()} ${d.months[dt.getMonth()]}`;
}

export function formatFullDate(ms: number, d: Dict): string {
  const dt = new Date(ms);
  return `${dt.getDate()} ${d.months[dt.getMonth()]} ${dt.getFullYear()}`;
}

export function formatTime(ms: number): string {
  const dt = new Date(ms);
  let h = dt.getHours();
  const m = dt.getMinutes();
  const ampm = h >= 12 ? "PM" : "AM";
  h = h % 12 || 12;
  return `${h}:${m.toString().padStart(2, "0")} ${ampm}`;
}

export function dateInputValue(ms: number): string {
  const dt = new Date(ms);
  const y = dt.getFullYear();
  const mo = (dt.getMonth() + 1).toString().padStart(2, "0");
  const day = dt.getDate().toString().padStart(2, "0");
  return `${y}-${mo}-${day}`;
}

export function startOfDay(ms: number): number {
  const d = new Date(ms);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}
