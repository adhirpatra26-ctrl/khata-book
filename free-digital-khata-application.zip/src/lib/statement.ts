import { Business, Customer, Transaction } from "./types";
import { Dict } from "./i18n";
import { formatINR, formatFullDate } from "./format";

export function buildStatementHTML(
  business: Business,
  customer: Customer,
  txns: Transaction[],
  d: Dict
): string {
  const sorted = [...txns].sort((a, b) => a.date - b.date || a.createdAt - b.createdAt);
  let running = 0;
  const totalGave = sorted
    .filter((t) => t.type === "gave")
    .reduce((a, t) => a + t.amount, 0);
  const totalRecv = sorted
    .filter((t) => t.type === "received")
    .reduce((a, t) => a + t.amount, 0);
  const closing = totalGave - totalRecv;
  const period =
    sorted.length > 0
      ? `${formatFullDate(sorted[0].date, d)} — ${formatFullDate(
          sorted[sorted.length - 1].date,
          d
        )}`
      : "—";

  const rows = sorted
    .map((t) => {
      running += t.type === "gave" ? t.amount : -t.amount;
      const gave = t.type === "gave" ? formatINR(t.amount) : "";
      const recv = t.type === "received" ? formatINR(t.amount) : "";
      return `<tr>
        <td>${formatFullDate(t.date, d)}</td>
        <td>${escapeHtml(t.description || (t.type === "received" ? d.youReceived : d.youGave))}${
        t.method ? ` <span class="muted">(${methodLabel(t.method, d)})</span>` : ""
      }</td>
        <td class="r red">${gave}</td>
        <td class="r green">${recv}</td>
        <td class="r bold">${formatINR(Math.abs(running))} ${running >= 0 ? d.due : d.advance}</td>
      </tr>`;
    })
    .join("");

  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>${escapeHtml(customer.name)} — ${d.statement}</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: -apple-system, "Segoe UI", Roboto, "Noto Sans", "Noto Sans Oriya", "Noto Sans Devanagari", sans-serif; color:#0f172a; margin:0; padding:28px; background:#fff; }
  .head { display:flex; justify-content:space-between; align-items:flex-start; border-bottom:3px solid #0e9488; padding-bottom:16px; }
  .brand { font-size:22px; font-weight:800; color:#0b7c72; }
  .biz { font-size:18px; font-weight:800; }
  .muted { color:#64748b; font-size:12px; }
  h1 { font-size:16px; margin:20px 0 6px; }
  .grid { display:grid; grid-template-columns:1fr 1fr; gap:8px 20px; margin:14px 0 18px; font-size:13px; }
  .cell b { display:block; color:#64748b; font-weight:600; font-size:11px; text-transform:uppercase; letter-spacing:.03em; }
  .summary { display:flex; gap:12px; margin:16px 0; }
  .card { flex:1; border:1px solid #e2e8f0; border-radius:12px; padding:12px; }
  .card .lbl { font-size:11px; color:#64748b; font-weight:600; text-transform:uppercase; }
  .card .val { font-size:18px; font-weight:800; margin-top:4px; }
  table { width:100%; border-collapse:collapse; font-size:13px; margin-top:8px; }
  th { background:#f1f5f9; text-align:left; padding:9px 10px; font-size:11px; text-transform:uppercase; color:#475569; }
  td { padding:9px 10px; border-bottom:1px solid #eef2f6; }
  .r { text-align:right; }
  .red { color:#e11d48; } .green { color:#059669; } .bold { font-weight:700; }
  .foot { margin-top:22px; text-align:center; color:#94a3b8; font-size:11px; }
  .due-badge { display:inline-block; background:#fff1f2; color:#e11d48; padding:6px 12px; border-radius:999px; font-weight:800; font-size:15px; }
  @media print { body { padding:12px; } .noprint { display:none; } }
</style></head>
<body>
  <div class="head">
    <div>
      <div class="biz">${escapeHtml(business.businessName)}</div>
      <div class="muted">${escapeHtml(business.ownerName)}</div>
      <div class="muted">${d.contact}: ${escapeHtml(business.mobile || "—")}</div>
    </div>
    <div style="text-align:right">
      <div class="brand">${d.appName}</div>
      <div class="muted">${d.statement}</div>
    </div>
  </div>

  <div class="grid">
    <div class="cell"><b>${d.customers}</b>${escapeHtml(customer.name)}</div>
    <div class="cell"><b>${d.mobile}</b>${escapeHtml(customer.mobile || "—")}</div>
    <div class="cell"><b>${d.period}</b>${period}</div>
    <div class="cell"><b>${d.closingBalance}</b><span class="due-badge">${formatINR(
      Math.abs(closing)
    )} ${closing >= 0 ? d.due : d.advance}</span></div>
  </div>

  <div class="summary">
    <div class="card"><div class="lbl">${d.openingBalance}</div><div class="val">${formatINR(
      0
    )}</div></div>
    <div class="card"><div class="lbl">${d.totalGiven}</div><div class="val red">${formatINR(
      totalGave
    )}</div></div>
    <div class="card"><div class="lbl">${d.totalReceived}</div><div class="val green">${formatINR(
      totalRecv
    )}</div></div>
  </div>

  <table>
    <thead><tr>
      <th>${d.date}</th><th>${d.description}</th>
      <th class="r">${d.youGave}</th><th class="r">${d.youReceived}</th><th class="r">${d.balanceDue}</th>
    </tr></thead>
    <tbody>${rows || `<tr><td colspan="5" style="text-align:center;color:#94a3b8;padding:24px">${d.noTransactions}</td></tr>`}</tbody>
  </table>

  <div class="foot">${d.appName} — ${d.tagline} · ${new Date().toLocaleDateString()}</div>
</body></html>`;
}

function methodLabel(m: string, d: Dict): string {
  switch (m) {
    case "cash":
      return d.cash;
    case "upi":
      return d.upi;
    case "bank":
      return d.bankTransfer;
    default:
      return d.other;
  }
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export function openPrint(html: string) {
  const w = window.open("", "_blank");
  if (!w) return;
  w.document.write(html);
  w.document.close();
  w.focus();
  setTimeout(() => w.print(), 400);
}

export function downloadHTML(html: string, filename: string) {
  const blob = new Blob([html], { type: "text/html;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function csvEscape(v: string | number): string {
  const s = String(v);
  if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

export function downloadCSV(csv: string, filename: string) {
  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
