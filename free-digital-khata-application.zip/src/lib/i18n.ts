import { Lang } from "./types";

export type Dict = {
  appName: string;
  tagline: string;
  goodMorning: string;
  goodAfternoon: string;
  goodEvening: string;
  totalToReceive: string;
  todaysSales: string;
  todaysReceived: string;
  customers: string;
  quickActions: string;
  giveCredit: string;
  receivePayment: string;
  addCustomer: string;
  pendingCustomers: string;
  due: string;
  remind: string;
  noPending: string;
  allSettled: string;
  searchCustomer: string;
  noCustomers: string;
  addFirstCustomer: string;
  totalDue: string;
  youAdvance: string; // when customer has paid extra (you owe them / advance)
  youGave: string;
  youReceived: string;
  currentBalance: string;
  noTransactions: string;
  addTransaction: string;
  amount: string;
  description: string;
  descriptionPlaceholder: string;
  date: string;
  paymentMethod: string;
  optionalNote: string;
  saveTransaction: string;
  savePayment: string;
  cash: string;
  upi: string;
  bankTransfer: string;
  other: string;
  shareKhata: string;
  downloadPdf: string;
  sharePdf: string;
  print: string;
  reports: string;
  today: string;
  thisWeek: string;
  thisMonth: string;
  customRange: string;
  totalGiven: string;
  totalReceived: string;
  totalOutstanding: string;
  sales: string;
  more: string;
  home: string;
  settings: string;
  language: string;
  security: string;
  pinLock: string;
  setPin: string;
  changePin: string;
  removePin: string;
  autoLock: string;
  backupExport: string;
  exportData: string;
  importData: string;
  exportCsv: string;
  about: string;
  free: string;
  freeMessage: string;
  name: string;
  mobile: string;
  save: string;
  cancel: string;
  delete: string;
  deleteTxConfirm: string;
  deleteCustomerConfirm: string;
  invalidAmount: string;
  requiredName: string;
  createBusiness: string;
  businessName: string;
  ownerName: string;
  startUsingApp: string;
  onboard1Title: string;
  onboard1Body: string;
  onboard2Title: string;
  onboard2Body: string;
  onboard3Title: string;
  onboard3Body: string;
  next: string;
  skip: string;
  getStarted: string;
  editCustomer: string;
  customerDetails: string;
  reminderMsg: (name: string, amount: string) => string;
  enterPin: string;
  wrongPin: string;
  unlock: string;
  appLocked: string;
  confirmPin: string;
  pinMismatch: string;
  statement: string;
  openingBalance: string;
  closingBalance: string;
  period: string;
  contact: string;
  editMessage: string;
  sendWhatsApp: string;
  perYou: string; // "to you" / "you get" label helper
  perThem: string;
  balanceDue: string;
  settled: string;
  advance: string;
  entries: string;
  viewKhata: string;
  netBalance: string;
  months: string[];
  daysShort: string[];
};

const en: Dict = {
  appName: "HisabGo",
  tagline: "Your Simple Digital Khata",
  goodMorning: "Good Morning",
  goodAfternoon: "Good Afternoon",
  goodEvening: "Good Evening",
  totalToReceive: "Total To Receive",
  todaysSales: "Today's Sales",
  todaysReceived: "Today's Received",
  customers: "Customers",
  quickActions: "Quick Actions",
  giveCredit: "Give Credit",
  receivePayment: "Receive Payment",
  addCustomer: "Add Customer",
  pendingCustomers: "Customers with Pending Balance",
  due: "Due",
  remind: "Remind",
  noPending: "No pending balances",
  allSettled: "All customers are settled up 🎉",
  searchCustomer: "Search customer...",
  noCustomers: "No customers yet",
  addFirstCustomer: "Add your first customer to get started",
  totalDue: "Total Due",
  youAdvance: "Advance",
  youGave: "You Gave",
  youReceived: "You Received",
  currentBalance: "Current Balance",
  noTransactions: "No transactions yet",
  addTransaction: "Add Transaction",
  amount: "Amount",
  description: "Description",
  descriptionPlaceholder: "What was this for?",
  date: "Date",
  paymentMethod: "Payment Method",
  optionalNote: "Note (optional)",
  saveTransaction: "Save Transaction",
  savePayment: "Save Payment",
  cash: "Cash",
  upi: "UPI",
  bankTransfer: "Bank Transfer",
  other: "Other",
  shareKhata: "Share Khata",
  downloadPdf: "Download PDF",
  sharePdf: "Share PDF",
  print: "Print",
  reports: "Reports",
  today: "Today",
  thisWeek: "This Week",
  thisMonth: "This Month",
  customRange: "Custom",
  totalGiven: "Total Given",
  totalReceived: "Total Received",
  totalOutstanding: "Total Outstanding",
  sales: "Sales",
  more: "More",
  home: "Home",
  settings: "Settings",
  language: "Language",
  security: "Security",
  pinLock: "PIN Lock",
  setPin: "Set PIN",
  changePin: "Change PIN",
  removePin: "Remove PIN",
  autoLock: "Auto Lock when app opens",
  backupExport: "Backup & Export",
  exportData: "Export Backup (JSON)",
  importData: "Import Backup",
  exportCsv: "Export as CSV",
  about: "About",
  free: "100% FREE",
  freeMessage: "Everything you need for your daily khata — FREE. No subscriptions, no locked features.",
  name: "Name",
  mobile: "Mobile Number",
  save: "Save",
  cancel: "Cancel",
  delete: "Delete",
  deleteTxConfirm: "Delete this transaction?",
  deleteCustomerConfirm: "Delete this customer and all their transactions?",
  invalidAmount: "Please enter a valid amount.",
  requiredName: "Please enter a customer name.",
  createBusiness: "Create Your Business",
  businessName: "Business Name",
  ownerName: "Owner Name",
  startUsingApp: "Start Using App",
  onboard1Title: "Your Simple Digital Khata",
  onboard1Body: "Track customer balances without complicated accounting.",
  onboard2Title: "Give. Receive. Done.",
  onboard2Body: "Record every transaction in seconds.",
  onboard3Title: "Your Khata, Always With You",
  onboard3Body: "Search, share and manage customer balances easily.",
  next: "Next",
  skip: "Skip",
  getStarted: "Get Started",
  editCustomer: "Edit Customer",
  customerDetails: "Customer Details",
  reminderMsg: (name, amount) =>
    `Hello ${name}, your current pending balance is ${amount}. Please clear the pending amount at your convenience. Thank you.`,
  enterPin: "Enter PIN",
  wrongPin: "Wrong PIN, try again",
  unlock: "Unlock",
  appLocked: "App Locked",
  confirmPin: "Confirm PIN",
  pinMismatch: "PINs do not match",
  statement: "Statement",
  openingBalance: "Opening Balance",
  closingBalance: "Closing Balance",
  period: "Statement Period",
  contact: "Contact",
  editMessage: "Edit message before sending",
  sendWhatsApp: "Send on WhatsApp",
  perYou: "you will get",
  perThem: "you will give",
  balanceDue: "Balance Due",
  settled: "Settled",
  advance: "Advance",
  entries: "entries",
  viewKhata: "View Khata",
  netBalance: "Net Balance",
  months: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],
  daysShort: ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],
};

const hi: Dict = {
  ...en,
  appName: "HisabGo",
  tagline: "आपका आसान डिजिटल खाता",
  goodMorning: "सुप्रभात",
  goodAfternoon: "नमस्ते",
  goodEvening: "शुभ संध्या",
  totalToReceive: "कुल लेना है",
  todaysSales: "आज की बिक्री",
  todaysReceived: "आज मिला",
  customers: "ग्राहक",
  quickActions: "त्वरित कार्य",
  giveCredit: "उधार दें",
  receivePayment: "भुगतान लें",
  addCustomer: "ग्राहक जोड़ें",
  pendingCustomers: "बकाया वाले ग्राहक",
  due: "बाकी",
  remind: "याद दिलाएं",
  noPending: "कोई बकाया नहीं",
  allSettled: "सभी ग्राहकों का हिसाब पूरा 🎉",
  searchCustomer: "ग्राहक खोजें...",
  noCustomers: "अभी कोई ग्राहक नहीं",
  addFirstCustomer: "शुरू करने के लिए पहला ग्राहक जोड़ें",
  totalDue: "कुल बकाया",
  youAdvance: "अग्रिम",
  youGave: "आपने दिए",
  youReceived: "आपको मिले",
  currentBalance: "वर्तमान शेष",
  noTransactions: "अभी कोई लेन-देन नहीं",
  addTransaction: "लेन-देन जोड़ें",
  amount: "राशि",
  description: "विवरण",
  descriptionPlaceholder: "किस लिए था?",
  date: "तारीख",
  paymentMethod: "भुगतान का तरीका",
  optionalNote: "नोट (वैकल्पिक)",
  saveTransaction: "लेन-देन सहेजें",
  savePayment: "भुगतान सहेजें",
  cash: "नकद",
  upi: "यूपीआई",
  bankTransfer: "बैंक ट्रांसफर",
  other: "अन्य",
  shareKhata: "खाता साझा करें",
  downloadPdf: "PDF डाउनलोड करें",
  sharePdf: "PDF साझा करें",
  print: "प्रिंट",
  reports: "रिपोर्ट",
  today: "आज",
  thisWeek: "इस सप्ताह",
  thisMonth: "इस महीने",
  customRange: "कस्टम",
  totalGiven: "कुल दिया",
  totalReceived: "कुल मिला",
  totalOutstanding: "कुल बकाया",
  sales: "बिक्री",
  more: "और",
  home: "होम",
  settings: "सेटिंग",
  language: "भाषा",
  security: "सुरक्षा",
  pinLock: "पिन लॉक",
  setPin: "पिन सेट करें",
  changePin: "पिन बदलें",
  removePin: "पिन हटाएं",
  autoLock: "ऐप खुलने पर लॉक करें",
  backupExport: "बैकअप और निर्यात",
  exportData: "बैकअप निर्यात (JSON)",
  importData: "बैकअप आयात करें",
  exportCsv: "CSV के रूप में निर्यात",
  about: "जानकारी",
  free: "100% मुफ़्त",
  freeMessage: "आपके रोज़ के खाते के लिए सब कुछ — मुफ़्त। कोई सब्सक्रिप्शन नहीं, कोई फीचर बंद नहीं।",
  name: "नाम",
  mobile: "मोबाइल नंबर",
  save: "सहेजें",
  cancel: "रद्द करें",
  delete: "हटाएं",
  deleteTxConfirm: "यह लेन-देन हटाएं?",
  deleteCustomerConfirm: "इस ग्राहक और सभी लेन-देन को हटाएं?",
  invalidAmount: "कृपया सही राशि दर्ज करें।",
  requiredName: "कृपया ग्राहक का नाम दर्ज करें।",
  createBusiness: "अपना व्यवसाय बनाएं",
  businessName: "व्यवसाय का नाम",
  ownerName: "मालिक का नाम",
  startUsingApp: "ऐप शुरू करें",
  onboard1Title: "आपका आसान डिजिटल खाता",
  onboard1Body: "जटिल हिसाब-किताब के बिना ग्राहक का बकाया देखें।",
  onboard2Title: "दें। लें। हो गया।",
  onboard2Body: "हर लेन-देन कुछ सेकंड में दर्ज करें।",
  onboard3Title: "आपका खाता, हमेशा आपके साथ",
  onboard3Body: "ग्राहक का बकाया आसानी से खोजें, साझा करें और संभालें।",
  next: "आगे",
  skip: "छोड़ें",
  getStarted: "शुरू करें",
  editCustomer: "ग्राहक संपादित करें",
  customerDetails: "ग्राहक विवरण",
  reminderMsg: (name, amount) =>
    `नमस्ते ${name}, आपका बकाया ${amount} है। कृपया सुविधानुसार बकाया राशि चुका दें। धन्यवाद।`,
  enterPin: "पिन दर्ज करें",
  wrongPin: "गलत पिन, फिर कोशिश करें",
  unlock: "अनलॉक",
  appLocked: "ऐप लॉक है",
  confirmPin: "पिन की पुष्टि करें",
  pinMismatch: "पिन मेल नहीं खाते",
  statement: "विवरण",
  openingBalance: "प्रारंभिक शेष",
  closingBalance: "अंतिम शेष",
  period: "अवधि",
  contact: "संपर्क",
  editMessage: "भेजने से पहले संदेश संपादित करें",
  sendWhatsApp: "व्हाट्सएप पर भेजें",
  perYou: "आपको मिलेंगे",
  perThem: "आप देंगे",
  balanceDue: "बकाया",
  settled: "पूरा",
  advance: "अग्रिम",
  entries: "प्रविष्टियां",
  viewKhata: "खाता देखें",
  netBalance: "कुल शेष",
  months: ["जन","फर","मार्च","अप्रैल","मई","जून","जुलाई","अग","सित","अक्तू","नव","दिस"],
  daysShort: ["रवि","सोम","मंगल","बुध","गुरु","शुक्र","शनि"],
};

const or: Dict = {
  ...en,
  appName: "HisabGo",
  tagline: "ଆପଣଙ୍କ ସହଜ ଡିଜିଟାଲ୍ ଖାତା",
  goodMorning: "ଶୁଭ ସକାଳ",
  goodAfternoon: "ନମସ୍କାର",
  goodEvening: "ଶୁଭ ସନ୍ଧ୍ୟା",
  totalToReceive: "ମୋଟ ପାଇବାର ଅଛି",
  todaysSales: "ଆଜିର ବିକ୍ରି",
  todaysReceived: "ଆଜି ମିଳିଲା",
  customers: "ଗ୍ରାହକ",
  quickActions: "ଶୀଘ୍ର କାମ",
  giveCredit: "ଉଧାର ଦିଅନ୍ତୁ",
  receivePayment: "ଦେୟ ନିଅନ୍ତୁ",
  addCustomer: "ଗ୍ରାହକ ଯୋଡ଼ନ୍ତୁ",
  pendingCustomers: "ବକେୟା ଥିବା ଗ୍ରାହକ",
  due: "ବାକି",
  remind: "ମନେ ପକାନ୍ତୁ",
  noPending: "କୌଣସି ବକେୟା ନାହିଁ",
  allSettled: "ସମସ୍ତ ଗ୍ରାହକଙ୍କ ହିସାବ ସରିଛି 🎉",
  searchCustomer: "ଗ୍ରାହକ ଖୋଜନ୍ତୁ...",
  noCustomers: "ଏବେ କୌଣସି ଗ୍ରାହକ ନାହିଁ",
  addFirstCustomer: "ଆରମ୍ଭ କରିବାକୁ ପ୍ରଥମ ଗ୍ରାହକ ଯୋଡ଼ନ୍ତୁ",
  totalDue: "ମୋଟ ବାକି",
  youAdvance: "ଅଗ୍ରୀମ",
  youGave: "ଆପଣ ଦେଲେ",
  youReceived: "ଆପଣ ପାଇଲେ",
  currentBalance: "ବର୍ତ୍ତମାନ ବାକି",
  noTransactions: "ଏବେ କୌଣସି କାରବାର ନାହିଁ",
  addTransaction: "କାରବାର ଯୋଡ଼ନ୍ତୁ",
  amount: "ରାଶି",
  description: "ବିବରଣୀ",
  descriptionPlaceholder: "ଏହା କାହିଁକି ଥିଲା?",
  date: "ତାରିଖ",
  paymentMethod: "ଦେୟ ମାଧ୍ୟମ",
  optionalNote: "ଟିପ୍ପଣୀ (ଐଚ୍ଛିକ)",
  saveTransaction: "କାରବାର ସେଭ୍ କରନ୍ତୁ",
  savePayment: "ଦେୟ ସେଭ୍ କରନ୍ତୁ",
  cash: "ନଗଦ",
  upi: "ୟୁପିଆଇ",
  bankTransfer: "ବ୍ୟାଙ୍କ ଟ୍ରାନ୍ସଫର",
  other: "ଅନ୍ୟାନ୍ୟ",
  shareKhata: "ଖାତା ସେୟାର କରନ୍ତୁ",
  downloadPdf: "PDF ଡାଉନଲୋଡ୍ କରନ୍ତୁ",
  sharePdf: "PDF ସେୟାର କରନ୍ତୁ",
  print: "ପ୍ରିଣ୍ଟ",
  reports: "ରିପୋର୍ଟ",
  today: "ଆଜି",
  thisWeek: "ଏହି ସପ୍ତାହ",
  thisMonth: "ଏହି ମାସ",
  customRange: "କଷ୍ଟମ",
  totalGiven: "ମୋଟ ଦିଆଗଲା",
  totalReceived: "ମୋଟ ମିଳିଲା",
  totalOutstanding: "ମୋଟ ବକେୟା",
  sales: "ବିକ୍ରି",
  more: "ଅଧିକ",
  home: "ହୋମ",
  settings: "ସେଟିଂସ",
  language: "ଭାଷା",
  security: "ସୁରକ୍ଷା",
  pinLock: "ପିନ ଲକ୍",
  setPin: "ପିନ ସେଟ କରନ୍ତୁ",
  changePin: "ପିନ ବଦଳାନ୍ତୁ",
  removePin: "ପିନ ହଟାନ୍ତୁ",
  autoLock: "ଆପ୍ ଖୋଲିଲେ ଲକ୍ କରନ୍ତୁ",
  backupExport: "ବ୍ୟାକଅପ୍ ଏବଂ ଏକ୍ସପୋର୍ଟ",
  exportData: "ବ୍ୟାକଅପ୍ ଏକ୍ସପୋର୍ଟ (JSON)",
  importData: "ବ୍ୟାକଅପ୍ ଇମ୍ପୋର୍ଟ",
  exportCsv: "CSV ଭାବରେ ଏକ୍ସପୋର୍ଟ",
  about: "ବିଷୟରେ",
  free: "100% ମାଗଣା",
  freeMessage: "ଆପଣଙ୍କ ଦୈନିକ ଖାତା ପାଇଁ ସବୁକିଛି — ମାଗଣା। କୌଣସି ସବସ୍କ୍ରିପସନ ନାହିଁ, କୌଣସି ଫିଚର ବନ୍ଦ ନାହିଁ।",
  name: "ନାମ",
  mobile: "ମୋବାଇଲ ନମ୍ବର",
  save: "ସେଭ୍ କରନ୍ତୁ",
  cancel: "ବାତିଲ୍ କରନ୍ତୁ",
  delete: "ଡିଲିଟ୍ କରନ୍ତୁ",
  deleteTxConfirm: "ଏହି କାରବାର ଡିଲିଟ୍ କରିବେ?",
  deleteCustomerConfirm: "ଏହି ଗ୍ରାହକ ଏବଂ ସମସ୍ତ କାରବାର ଡିଲିଟ୍ କରିବେ?",
  invalidAmount: "ଦୟାକରି ଏକ ସଠିକ ରାଶି ଦିଅନ୍ତୁ।",
  requiredName: "ଦୟାକରି ଗ୍ରାହକଙ୍କ ନାମ ଦିଅନ୍ତୁ।",
  createBusiness: "ଆପଣଙ୍କ ବ୍ୟବସାୟ ତିଆରି କରନ୍ତୁ",
  businessName: "ବ୍ୟବସାୟ ନାମ",
  ownerName: "ମାଲିକଙ୍କ ନାମ",
  startUsingApp: "ଆପ୍ ବ୍ୟବହାର ଆରମ୍ଭ କରନ୍ତୁ",
  onboard1Title: "ଆପଣଙ୍କ ସହଜ ଡିଜିଟାଲ୍ ଖାତା",
  onboard1Body: "ଜଟିଳ ହିସାବ ବିନା ଗ୍ରାହକଙ୍କ ବାକି ଦେଖନ୍ତୁ।",
  onboard2Title: "ଦିଅନ୍ତୁ। ନିଅନ୍ତୁ। ସରିଲା।",
  onboard2Body: "ପ୍ରତ୍ୟେକ କାରବାର କିଛି ସେକେଣ୍ଡରେ ରେକର୍ଡ କରନ୍ତୁ।",
  onboard3Title: "ଆପଣଙ୍କ ଖାତା, ସର୍ବଦା ଆପଣଙ୍କ ସହ",
  onboard3Body: "ଗ୍ରାହକଙ୍କ ବାକି ସହଜରେ ଖୋଜନ୍ତୁ, ସେୟାର କରନ୍ତୁ ଏବଂ ପରିଚାଳନା କରନ୍ତୁ।",
  next: "ପରବର୍ତ୍ତୀ",
  skip: "ଛାଡ଼ନ୍ତୁ",
  getStarted: "ଆରମ୍ଭ କରନ୍ତୁ",
  editCustomer: "ଗ୍ରାହକ ସମ୍ପାଦନ କରନ୍ତୁ",
  customerDetails: "ଗ୍ରାହକ ବିବରଣୀ",
  reminderMsg: (name, amount) =>
    `ନମସ୍କାର ${name}, ଆପଣଙ୍କ ବକେୟା ରାଶି ${amount}। ଦୟାକରି ସୁବିଧା ଅନୁସାରେ ବକେୟା ରାଶି ପରିଶୋଧ କରନ୍ତୁ। ଧନ୍ୟବାଦ।`,
  enterPin: "ପିନ ଦିଅନ୍ତୁ",
  wrongPin: "ଭୁଲ ପିନ, ପୁଣି ଚେଷ୍ଟା କରନ୍ତୁ",
  unlock: "ଅନଲକ୍",
  appLocked: "ଆପ୍ ଲକ୍ ଅଛି",
  confirmPin: "ପିନ ନିଶ୍ଚିତ କରନ୍ତୁ",
  pinMismatch: "ପିନ ମିଳୁନାହିଁ",
  statement: "ବିବରଣୀ",
  openingBalance: "ଆରମ୍ଭିକ ବାକି",
  closingBalance: "ଅନ୍ତିମ ବାକି",
  period: "ଅବଧି",
  contact: "ଯୋଗାଯୋଗ",
  editMessage: "ପଠାଇବା ପୂର୍ବରୁ ବାର୍ତ୍ତା ସମ୍ପାଦନ କରନ୍ତୁ",
  sendWhatsApp: "ହ୍ୱାଟସଆପରେ ପଠାନ୍ତୁ",
  perYou: "ଆପଣ ପାଇବେ",
  perThem: "ଆପଣ ଦେବେ",
  balanceDue: "ବାକି",
  settled: "ସରିଛି",
  advance: "ଅଗ୍ରୀମ",
  entries: "ଏଣ୍ଟ୍ରି",
  viewKhata: "ଖାତା ଦେଖନ୍ତୁ",
  netBalance: "ମୋଟ ବାକି",
  months: ["ଜାନୁ","ଫେବ୍ରୁ","ମାର୍ଚ୍ଚ","ଅପ୍ରେଲ","ମେ","ଜୁନ","ଜୁଲାଇ","ଅଗଷ୍ଟ","ସେପ୍ଟେ","ଅକ୍ଟୋ","ନଭେ","ଡିସେ"],
  daysShort: ["ରବି","ସୋମ","ମଙ୍ଗଳ","ବୁଧ","ଗୁରୁ","ଶୁକ୍ର","ଶନି"],
};

export const dictionaries: Record<Lang, Dict> = { en, hi, or };

export const languageNames: Record<Lang, string> = {
  en: "English",
  hi: "हिन्दी",
  or: "ଓଡ଼ିଆ",
};

export function getDict(lang: Lang): Dict {
  return dictionaries[lang] || en;
}
