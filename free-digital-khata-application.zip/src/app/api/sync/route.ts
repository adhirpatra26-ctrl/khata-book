import { db } from "@/db";
import { businesses, customers, transactions } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

type Body = {
  business: {
    deviceId: string;
    businessName: string;
    ownerName: string;
    mobile: string;
    language: string;
  };
  customers: {
    id: string;
    name: string;
    mobile: string;
    note: string;
    createdAt: number;
  }[];
  transactions: {
    id: string;
    customerId: string;
    type: string;
    amount: number;
    description: string;
    method: string;
    note: string;
    date: number;
    createdAt: number;
  }[];
};

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as Body;
    const { business, customers: cs, transactions: ts } = body;
    if (!business?.deviceId) {
      return Response.json({ ok: false, error: "missing deviceId" }, { status: 400 });
    }
    const deviceId = business.deviceId;

    // Upsert business
    await db
      .insert(businesses)
      .values({
        deviceId,
        businessName: business.businessName,
        ownerName: business.ownerName,
        mobile: business.mobile || "",
        language: business.language || "en",
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: businesses.deviceId,
        set: {
          businessName: business.businessName,
          ownerName: business.ownerName,
          mobile: business.mobile || "",
          language: business.language || "en",
          updatedAt: new Date(),
        },
      });

    // Replace customers & transactions for this device (full snapshot sync)
    await db.delete(transactions).where(eq(transactions.deviceId, deviceId));
    await db.delete(customers).where(eq(customers.deviceId, deviceId));

    if (cs.length) {
      await db.insert(customers).values(
        cs.map((c) => ({
          id: c.id,
          deviceId,
          name: c.name,
          mobile: c.mobile || "",
          note: c.note || "",
          createdAt: c.createdAt,
        }))
      );
    }

    if (ts.length) {
      await db.insert(transactions).values(
        ts.map((t) => ({
          id: t.id,
          deviceId,
          customerId: t.customerId,
          type: t.type,
          amount: t.amount,
          description: t.description || "",
          method: t.method || "",
          note: t.note || "",
          date: t.date,
          createdAt: t.createdAt,
        }))
      );
    }

    return Response.json({ ok: true });
  } catch (e) {
    return Response.json(
      { ok: false, error: e instanceof Error ? e.message : "error" },
      { status: 500 }
    );
  }
}

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const deviceId = url.searchParams.get("deviceId");
    if (!deviceId) {
      return Response.json({ ok: false, error: "missing deviceId" }, { status: 400 });
    }
    const b = await db
      .select()
      .from(businesses)
      .where(eq(businesses.deviceId, deviceId))
      .limit(1);
    const cs = await db
      .select()
      .from(customers)
      .where(eq(customers.deviceId, deviceId));
    const ts = await db
      .select()
      .from(transactions)
      .where(eq(transactions.deviceId, deviceId))
      .orderBy(sql`${transactions.date} asc`);
    return Response.json({ ok: true, business: b[0] || null, customers: cs, transactions: ts });
  } catch (e) {
    return Response.json(
      { ok: false, error: e instanceof Error ? e.message : "error" },
      { status: 500 }
    );
  }
}
