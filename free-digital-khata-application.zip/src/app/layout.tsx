import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { StoreProvider } from "@/lib/store";

export const metadata: Metadata = {
  title: "HisabGo — Your Simple Digital Khata",
  description:
    "HisabGo is a completely free digital khata & business ledger. Track customer credit, record payments, share on WhatsApp and download PDF statements.",
};

export const viewport: Viewport = {
  themeColor: "#0e9488",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <StoreProvider>
          <div className="app-shell">{children}</div>
        </StoreProvider>
      </body>
    </html>
  );
}
