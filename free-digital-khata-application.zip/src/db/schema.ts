import {
  pgTable,
  serial,
  text,
  timestamp,
  integer,
  bigint,
} from "drizzle-orm/pg-core";

// A business belongs to a device/owner. Identified by a client-generated deviceId.
export const businesses = pgTable("businesses", {
  id: serial("id").primaryKey(),
  deviceId: text("device_id").notNull().unique(),
  businessName: text("business_name").notNull(),
  ownerName: text("owner_name").notNull(),
  mobile: text("mobile").notNull().default(""),
  language: text("language").notNull().default("en"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const customers = pgTable("customers", {
  id: text("id").primaryKey(), // client-generated uuid
  deviceId: text("device_id").notNull(),
  name: text("name").notNull(),
  mobile: text("mobile").notNull().default(""),
  note: text("note").notNull().default(""),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
});

export const transactions = pgTable("transactions", {
  id: text("id").primaryKey(), // client-generated uuid
  deviceId: text("device_id").notNull(),
  customerId: text("customer_id").notNull(),
  // "gave" (you gave credit, increases due) or "received" (you received payment, decreases due)
  type: text("type").notNull(),
  // amount stored in paise (integer) to avoid floating point issues
  amount: integer("amount").notNull(),
  description: text("description").notNull().default(""),
  method: text("method").notNull().default(""), // cash/upi/bank/other
  note: text("note").notNull().default(""),
  date: bigint("date", { mode: "number" }).notNull(), // epoch ms for the transaction date
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
});
