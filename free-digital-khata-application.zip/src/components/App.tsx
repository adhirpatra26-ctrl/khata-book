"use client";

import { useEffect, useState } from "react";
import { useStore } from "@/lib/store";
import { Customer, TxType } from "@/lib/types";
import { Onboarding } from "./Onboarding";
import { LockScreen } from "./LockScreen";
import { BottomNav, Tab } from "./BottomNav";
import { HomeScreen } from "./screens/HomeScreen";
import { CustomersScreen } from "./screens/CustomersScreen";
import { ReportsScreen } from "./screens/ReportsScreen";
import { MoreScreen } from "./screens/MoreScreen";
import { KhataScreen } from "./screens/KhataScreen";
import { TransactionSheet } from "./TransactionSheet";
import { CustomerSheet } from "./CustomerSheet";
import { RemindSheet } from "./RemindSheet";
import { ShareSheet } from "./ShareSheet";
import { PickCustomerSheet } from "./PickCustomerSheet";
import { Toast } from "./ui";
import { Logo } from "./Icons";

export function App() {
  const { ready, business, onboarded, hasPin, autoLock, d, customers } = useStore();
  const [locked, setLocked] = useState(false);
  const [tab, setTab] = useState<Tab>("home");
  const [openCustomer, setOpenCustomer] = useState<Customer | null>(null);

  // Sheets
  const [txSheet, setTxSheet] = useState<{ open: boolean; type: TxType; customer: Customer | null }>({
    open: false,
    type: "gave",
    customer: null,
  });
  const [custSheet, setCustSheet] = useState<{ open: boolean; editing: Customer | null }>({
    open: false,
    editing: null,
  });
  const [remind, setRemind] = useState<Customer | null>(null);
  const [share, setShare] = useState<Customer | null>(null);
  const [pick, setPick] = useState<{ open: boolean; type: TxType }>({ open: false, type: "gave" });
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    if (ready && hasPin && autoLock) setLocked(true);
  }, [ready, hasPin, autoLock]);

  const showToast = (m: string) => {
    setToast(m);
    setTimeout(() => setToast(null), 1800);
  };

  // keep openCustomer fresh after edits
  const currentCustomer = openCustomer
    ? customers.find((c) => c.id === openCustomer.id) || openCustomer
    : null;

  if (!ready) {
    return (
      <div className="flex min-h-[100dvh] items-center justify-center bg-white">
        <div className="animate-pulse">
          <Logo size={56} />
        </div>
      </div>
    );
  }

  if (!business || !onboarded) {
    return <Onboarding />;
  }

  if (locked) {
    return <LockScreen onUnlock={() => setLocked(false)} />;
  }

  // Detail view (customer khata)
  if (currentCustomer) {
    return (
      <>
        <KhataScreen
          customer={currentCustomer}
          onBack={() => setOpenCustomer(null)}
          onAddTx={(type) =>
            setTxSheet({ open: true, type, customer: currentCustomer })
          }
          onRemind={() => setRemind(currentCustomer)}
          onShare={() => setShare(currentCustomer)}
          onEdit={() => setCustSheet({ open: true, editing: currentCustomer })}
        />
        <Sheets />
      </>
    );
  }

  return (
    <>
      <div className="min-h-[100dvh]">
        {tab === "home" && (
          <HomeScreen
            onOpenCustomer={setOpenCustomer}
            onGive={() => setPick({ open: true, type: "gave" })}
            onReceive={() => setPick({ open: true, type: "received" })}
            onAddCustomer={() => setCustSheet({ open: true, editing: null })}
            onRemind={setRemind}
            onSeeAll={() => setTab("customers")}
          />
        )}
        {tab === "customers" && (
          <CustomersScreen
            onOpenCustomer={setOpenCustomer}
            onAddCustomer={() => setCustSheet({ open: true, editing: null })}
          />
        )}
        {tab === "reports" && <ReportsScreen />}
        {tab === "more" && <MoreScreen onToast={showToast} />}
      </div>

      <BottomNav
        active={tab}
        onChange={(t) => {
          setTab(t);
          setOpenCustomer(null);
        }}
        onAdd={() => setPick({ open: true, type: "gave" })}
      />

      <Sheets />
    </>
  );

  function Sheets() {
    return (
      <>
        <TransactionSheet
          open={txSheet.open}
          onClose={() => setTxSheet((s) => ({ ...s, open: false }))}
          customer={txSheet.customer}
          initialType={txSheet.type}
          onSaved={() => showToast(d.saveTransaction + " ✓")}
        />
        <CustomerSheet
          open={custSheet.open}
          onClose={() => setCustSheet((s) => ({ ...s, open: false }))}
          editing={custSheet.editing}
          onCreated={(c) => {
            setOpenCustomer(c);
            showToast(d.addCustomer + " ✓");
          }}
        />
        <RemindSheet
          open={!!remind}
          onClose={() => setRemind(null)}
          customer={remind}
        />
        <ShareSheet open={!!share} onClose={() => setShare(null)} customer={share} />
        <PickCustomerSheet
          open={pick.open}
          onClose={() => setPick((s) => ({ ...s, open: false }))}
          title={pick.type === "gave" ? d.giveCredit : d.receivePayment}
          onPick={(c) => {
            setPick((s) => ({ ...s, open: false }));
            setTxSheet({ open: true, type: pick.type, customer: c });
          }}
          onAddNew={() => {
            setPick((s) => ({ ...s, open: false }));
            setCustSheet({ open: true, editing: null });
          }}
        />
        <Toast message={toast} />
      </>
    );
  }
}
