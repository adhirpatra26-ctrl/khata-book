"use client";

import { useState, useEffect } from "react";
import { useStore } from "@/lib/store";
import { Customer, PaymentMethod, TxType } from "@/lib/types";
import { rupeesToPaise, dateInputValue } from "@/lib/format";
import { Sheet, Field, inputCls, Avatar } from "./ui";
import { ArrowUp, ArrowDown } from "./Icons";

export function TransactionSheet({
  open,
  onClose,
  customer,
  initialType,
  onSaved,
}: {
  open: boolean;
  onClose: () => void;
  customer: Customer | null;
  initialType: TxType;
  onSaved?: () => void;
}) {
  const { d, addTransaction, balanceOf } = useStore();
  const [type, setType] = useState<TxType>(initialType);
  const [amount, setAmount] = useState("");
  const [desc, setDesc] = useState("");
  const [date, setDate] = useState(dateInputValue(Date.now()));
  const [method, setMethod] = useState<PaymentMethod>("cash");
  const [note, setNote] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (open) {
      setType(initialType);
      setAmount("");
      setDesc("");
      setDate(dateInputValue(Date.now()));
      setMethod("cash");
      setNote("");
      setError("");
    }
  }, [open, initialType]);

  if (!customer) return null;

  const save = () => {
    const paise = rupeesToPaise(amount);
    if (isNaN(paise) || paise <= 0) {
      setError(d.invalidAmount);
      return;
    }
    const dt = new Date(date);
    dt.setHours(12, 0, 0, 0);
    addTransaction({
      customerId: customer.id,
      type,
      amount: paise,
      description: desc.trim(),
      method: type === "received" ? method : "",
      note: note.trim(),
      date: isNaN(dt.getTime()) ? Date.now() : dt.getTime(),
    });
    onClose();
    onSaved?.();
  };

  const isReceived = type === "received";

  return (
    <Sheet open={open} onClose={onClose} title={d.addTransaction}>
      <div className="mb-4 flex items-center gap-3 rounded-2xl bg-slate-50 p-3">
        <Avatar name={customer.name} size={40} />
        <div className="min-w-0">
          <p className="truncate font-bold text-slate-900">{customer.name}</p>
          <p className="text-xs text-slate-500">{customer.mobile || "—"}</p>
        </div>
      </div>

      {/* Type toggle */}
      <div className="mb-4 grid grid-cols-2 gap-2 rounded-2xl bg-slate-100 p-1.5">
        <button
          onClick={() => setType("received")}
          className={`tap flex items-center justify-center gap-2 rounded-xl py-3 text-sm font-bold ${
            isReceived ? "bg-emerald-500 text-white shadow" : "text-slate-500"
          }`}
        >
          <ArrowDown width={18} /> {d.youReceived}
        </button>
        <button
          onClick={() => setType("gave")}
          className={`tap flex items-center justify-center gap-2 rounded-xl py-3 text-sm font-bold ${
            !isReceived ? "bg-rose-500 text-white shadow" : "text-slate-500"
          }`}
        >
          <ArrowUp width={18} /> {d.youGave}
        </button>
      </div>

      <Field label={d.amount}>
        <div
          className={`flex items-center rounded-xl border-2 bg-white px-4 ${
            error ? "border-rose-400" : "border-slate-200 focus-within:border-teal-500"
          }`}
        >
          <span className="mr-1 text-2xl font-bold text-slate-400">₹</span>
          <input
            inputMode="decimal"
            autoFocus
            value={amount}
            onChange={(e) => {
              setAmount(e.target.value.replace(/[^0-9.]/g, ""));
              setError("");
            }}
            placeholder="0"
            className="w-full bg-transparent py-3 text-3xl font-bold text-slate-900 outline-none"
          />
        </div>
      </Field>
      {error && <p className="-mt-2 mb-2 text-sm font-medium text-rose-600">{error}</p>}

      <Field label={d.description}>
        <input
          value={desc}
          onChange={(e) => setDesc(e.target.value)}
          placeholder={d.descriptionPlaceholder}
          className={inputCls}
        />
      </Field>

      {isReceived && (
        <Field label={d.paymentMethod}>
          <div className="grid grid-cols-2 gap-2">
            {(
              [
                ["cash", d.cash],
                ["upi", d.upi],
                ["bank", d.bankTransfer],
                ["other", d.other],
              ] as [PaymentMethod, string][]
            ).map(([m, label]) => (
              <button
                key={m}
                onClick={() => setMethod(m)}
                className={`tap rounded-xl border py-2.5 text-sm font-semibold ${
                  method === m
                    ? "border-teal-500 bg-teal-50 text-teal-700"
                    : "border-slate-200 bg-white text-slate-600"
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </Field>
      )}

      <Field label={d.date}>
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          className={inputCls}
        />
      </Field>

      <Field label={d.optionalNote}>
        <input
          value={note}
          onChange={(e) => setNote(e.target.value)}
          className={inputCls}
        />
      </Field>

      <button
        onClick={save}
        className={`tap mt-2 w-full rounded-2xl py-4 text-base font-bold text-white shadow-lg ${
          isReceived ? "bg-emerald-500" : "bg-rose-500"
        }`}
      >
        {isReceived ? d.savePayment : d.saveTransaction}
      </button>

      <p className="mt-3 text-center text-xs text-slate-400">
        {d.currentBalance}: ₹{(Math.abs(balanceOf(customer.id)) / 100).toLocaleString("en-IN")}
      </p>
    </Sheet>
  );
}
