"use client";

import { useState, useEffect } from "react";
import { useStore } from "@/lib/store";
import { Customer } from "@/lib/types";
import { Sheet, Field, inputCls } from "./ui";

export function CustomerSheet({
  open,
  onClose,
  editing,
  onCreated,
}: {
  open: boolean;
  onClose: () => void;
  editing?: Customer | null;
  onCreated?: (c: Customer) => void;
}) {
  const { d, addCustomer, updateCustomer } = useStore();
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");
  const [note, setNote] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (open) {
      setName(editing?.name || "");
      setMobile(editing?.mobile || "");
      setNote(editing?.note || "");
      setError("");
    }
  }, [open, editing]);

  const save = () => {
    if (!name.trim()) {
      setError(d.requiredName);
      return;
    }
    if (editing) {
      updateCustomer(editing.id, {
        name: name.trim(),
        mobile: mobile.trim(),
        note: note.trim(),
      });
      onClose();
    } else {
      const c = addCustomer({ name, mobile, note });
      onClose();
      onCreated?.(c);
    }
  };

  return (
    <Sheet
      open={open}
      onClose={onClose}
      title={editing ? d.editCustomer : d.addCustomer}
    >
      <Field label={d.name}>
        <input
          autoFocus
          value={name}
          onChange={(e) => {
            setName(e.target.value);
            setError("");
          }}
          placeholder={d.name}
          className={inputCls}
        />
      </Field>
      {error && <p className="-mt-2 mb-2 text-sm font-medium text-rose-600">{error}</p>}
      <Field label={d.mobile}>
        <input
          inputMode="tel"
          value={mobile}
          onChange={(e) => setMobile(e.target.value.replace(/[^0-9+]/g, ""))}
          placeholder="9876543210"
          className={inputCls}
        />
      </Field>
      <Field label={d.optionalNote}>
        <input
          value={note}
          onChange={(e) => setNote(e.target.value)}
          className={inputCls}
        />
      </Field>
      <button
        onClick={save}
        className="tap mt-2 w-full rounded-2xl bg-teal-600 py-4 text-base font-bold text-white shadow-lg"
      >
        {d.save}
      </button>
    </Sheet>
  );
}
