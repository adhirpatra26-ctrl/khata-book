"use client";

import { useMemo, useState } from "react";
import { useStore } from "@/lib/store";
import { Customer } from "@/lib/types";
import { Sheet, Avatar } from "./ui";
import { SearchIcon, PlusIcon } from "./Icons";
import { formatINR } from "@/lib/format";

export function PickCustomerSheet({
  open,
  onClose,
  onPick,
  onAddNew,
  title,
}: {
  open: boolean;
  onClose: () => void;
  onPick: (c: Customer) => void;
  onAddNew: () => void;
  title: string;
}) {
  const { d, customers, balanceOf } = useStore();
  const [q, setQ] = useState("");

  const list = useMemo(() => {
    const query = q.trim().toLowerCase();
    return customers.filter(
      (c) =>
        !query || c.name.toLowerCase().includes(query) || c.mobile.includes(query)
    );
  }, [customers, q]);

  return (
    <Sheet open={open} onClose={onClose} title={title}>
      <div className="mb-3 flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5">
        <SearchIcon width={18} className="text-slate-400" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={d.searchCustomer}
          className="w-full bg-transparent outline-none"
          autoFocus
        />
      </div>

      <button
        onClick={onAddNew}
        className="tap mb-3 flex w-full items-center gap-3 rounded-2xl border-2 border-dashed border-teal-200 bg-teal-50/50 p-3.5 text-left"
      >
        <span className="flex h-11 w-11 items-center justify-center rounded-full bg-teal-600 text-white">
          <PlusIcon width={22} />
        </span>
        <span className="font-bold text-teal-700">{d.addCustomer}</span>
      </button>

      <div className="max-h-[50vh] space-y-2 overflow-y-auto no-scrollbar">
        {list.map((c) => {
          const bal = balanceOf(c.id);
          return (
            <button
              key={c.id}
              onClick={() => onPick(c)}
              className="tap flex w-full items-center gap-3 rounded-2xl bg-white p-3 text-left ring-1 ring-slate-100"
            >
              <Avatar name={c.name} size={42} />
              <div className="min-w-0 flex-1">
                <p className="truncate font-bold text-slate-900">{c.name}</p>
                <p className="text-xs text-slate-400">{c.mobile || "—"}</p>
              </div>
              {bal !== 0 && (
                <span
                  className={`text-sm font-bold ${
                    bal > 0 ? "text-rose-600" : "text-emerald-600"
                  }`}
                >
                  {formatINR(Math.abs(bal))}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </Sheet>
  );
}
