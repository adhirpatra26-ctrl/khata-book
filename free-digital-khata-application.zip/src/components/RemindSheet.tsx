"use client";

import { useState, useEffect } from "react";
import { useStore } from "@/lib/store";
import { Customer } from "@/lib/types";
import { formatINR } from "@/lib/format";
import { Sheet } from "./ui";
import { WhatsAppIcon } from "./Icons";

export function RemindSheet({
  open,
  onClose,
  customer,
}: {
  open: boolean;
  onClose: () => void;
  customer: Customer | null;
}) {
  const { d, balanceOf } = useStore();
  const [msg, setMsg] = useState("");

  const balance = customer ? balanceOf(customer.id) : 0;

  useEffect(() => {
    if (open && customer) {
      setMsg(d.reminderMsg(customer.name, formatINR(Math.abs(balance))));
    }
  }, [open, customer, balance, d]);

  if (!customer) return null;

  const send = () => {
    const phone = customer.mobile.replace(/[^0-9]/g, "");
    const text = encodeURIComponent(msg);
    const url = phone
      ? `https://wa.me/91${phone.slice(-10)}?text=${text}`
      : `https://wa.me/?text=${text}`;
    window.open(url, "_blank");
    onClose();
  };

  return (
    <Sheet open={open} onClose={onClose} title={d.remind}>
      <div className="mb-4 rounded-2xl bg-rose-50 p-4 text-center">
        <p className="text-sm font-medium text-rose-500">{d.balanceDue}</p>
        <p className="text-3xl font-extrabold text-rose-600">
          {formatINR(Math.abs(balance))}
        </p>
        <p className="mt-1 text-sm font-semibold text-slate-700">{customer.name}</p>
      </div>

      <p className="mb-2 text-sm font-semibold text-slate-600">{d.editMessage}</p>
      <textarea
        value={msg}
        onChange={(e) => setMsg(e.target.value)}
        rows={5}
        className="w-full rounded-xl border border-slate-200 bg-slate-50 p-4 text-slate-800 outline-none focus:border-teal-500 focus:bg-white"
      />

      <button
        onClick={send}
        className="tap mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#25D366] py-4 text-base font-bold text-white shadow-lg"
      >
        <WhatsAppIcon width={22} height={22} /> {d.sendWhatsApp}
      </button>
    </Sheet>
  );
}
