"use client";

import { useState } from "react";
import { useStore } from "@/lib/store";
import { Lang } from "@/lib/types";
import { languageNames } from "@/lib/i18n";
import { Logo, ChevronRight, WalletIcon, WhatsAppIcon, CheckIcon } from "./Icons";
import { Field, inputCls } from "./ui";

export function Onboarding() {
  const { d, lang, setLang, createBusiness, markOnboarded, onboarded, business } =
    useStore();
  const [step, setStep] = useState(0);

  // If business already exists but not marked onboarded (edge), skip to done
  const slides = [
    {
      icon: <WalletIcon width={54} height={54} />,
      title: d.onboard1Title,
      body: d.onboard1Body,
      tint: "bg-teal-50 text-teal-600",
    },
    {
      icon: (
        <div className="flex gap-2">
          <span className="text-4xl">💸</span>
        </div>
      ),
      title: d.onboard2Title,
      body: d.onboard2Body,
      tint: "bg-amber-50 text-amber-600",
    },
    {
      icon: <WhatsAppIcon width={50} height={50} />,
      title: d.onboard3Title,
      body: d.onboard3Body,
      tint: "bg-emerald-50 text-emerald-600",
    },
  ];

  const showForm = step >= slides.length;

  return (
    <div className="flex min-h-[100dvh] flex-col bg-white px-6">
      {/* Top: brand + language */}
      <div className="flex items-center justify-between pt-8">
        <div className="flex items-center gap-2">
          <Logo size={34} />
          <span className="text-lg font-extrabold text-slate-900">{d.appName}</span>
        </div>
        <select
          value={lang}
          onChange={(e) => setLang(e.target.value as Lang)}
          className="rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-sm font-semibold text-slate-700 outline-none"
        >
          {(Object.keys(languageNames) as Lang[]).map((l) => (
            <option key={l} value={l}>
              {languageNames[l]}
            </option>
          ))}
        </select>
      </div>

      {!showForm ? (
        <div className="flex flex-1 flex-col">
          <div className="flex flex-1 flex-col items-center justify-center text-center">
            <div
              className={`mb-8 flex h-28 w-28 items-center justify-center rounded-[2rem] ${slides[step].tint}`}
            >
              {slides[step].icon}
            </div>
            <h1 className="mb-3 px-4 text-2xl font-extrabold text-slate-900">
              {slides[step].title}
            </h1>
            <p className="max-w-xs text-base leading-relaxed text-slate-500">
              {slides[step].body}
            </p>
          </div>

          {/* Dots */}
          <div className="mb-6 flex justify-center gap-2">
            {slides.map((_, i) => (
              <span
                key={i}
                className={`h-2 rounded-full transition-all ${
                  i === step ? "w-6 bg-teal-600" : "w-2 bg-slate-200"
                }`}
              />
            ))}
          </div>

          <div className="mb-8 flex items-center justify-between">
            <button
              onClick={() => setStep(slides.length)}
              className="tap px-2 py-2 font-semibold text-slate-400"
            >
              {d.skip}
            </button>
            <button
              onClick={() => setStep(step + 1)}
              className="tap flex items-center gap-1 rounded-2xl bg-teal-600 px-7 py-3.5 font-bold text-white shadow-lg"
            >
              {step === slides.length - 1 ? d.getStarted : d.next}
              <ChevronRight width={20} />
            </button>
          </div>
        </div>
      ) : (
        <BusinessForm />
      )}
    </div>
  );

  function BusinessForm() {
    const [bizName, setBizName] = useState(business?.businessName || "");
    const [owner, setOwner] = useState(business?.ownerName || "");
    const [mobile, setMobile] = useState(business?.mobile || "");
    const [err, setErr] = useState("");

    const start = () => {
      if (!bizName.trim() || !owner.trim()) {
        setErr(d.requiredName);
        return;
      }
      if (!business) {
        createBusiness({
          businessName: bizName,
          ownerName: owner,
          mobile,
        });
      }
      markOnboarded();
    };

    return (
      <div className="flex flex-1 flex-col pt-6">
        <div className="mb-6 flex flex-col items-center text-center">
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl brand-grad text-white">
            <Logo size={44} />
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900">
            {d.createBusiness}
          </h1>
          <p className="mt-1 text-sm text-slate-500">{d.tagline}</p>
        </div>

        <Field label={d.businessName}>
          <input
            value={bizName}
            onChange={(e) => {
              setBizName(e.target.value);
              setErr("");
            }}
            placeholder={d.businessName}
            className={inputCls}
          />
        </Field>
        <Field label={d.ownerName}>
          <input
            value={owner}
            onChange={(e) => {
              setOwner(e.target.value);
              setErr("");
            }}
            placeholder={d.ownerName}
            className={inputCls}
          />
        </Field>
        <Field label={d.mobile}>
          <input
            inputMode="tel"
            value={mobile}
            onChange={(e) => setMobile(e.target.value.replace(/[^0-9+]/g, ""))}
            placeholder="9876543210"
            className={inputCls}
          />
        </Field>
        {err && <p className="mb-2 text-sm font-medium text-rose-600">{err}</p>}

        <button
          onClick={start}
          className="tap mt-3 w-full rounded-2xl brand-grad py-4 text-base font-bold text-white shadow-lg"
        >
          {d.startUsingApp}
        </button>

        <div className="mt-5 flex items-center justify-center gap-2 rounded-xl bg-teal-50 px-4 py-3 text-sm font-semibold text-teal-700">
          <CheckIcon width={18} /> {d.free} · {d.tagline}
        </div>
      </div>
    );
  }
}
