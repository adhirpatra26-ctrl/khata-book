"use client";

import { useStore } from "@/lib/store";
import { HomeIcon, UsersIcon, ChartIcon, MoreIcon, PlusIcon } from "./Icons";

export type Tab = "home" | "customers" | "reports" | "more";

export function BottomNav({
  active,
  onChange,
  onAdd,
}: {
  active: Tab;
  onChange: (t: Tab) => void;
  onAdd: () => void;
}) {
  const { d } = useStore();
  const items: { key: Tab; label: string; Icon: typeof HomeIcon }[] = [
    { key: "home", label: d.home, Icon: HomeIcon },
    { key: "customers", label: d.customers, Icon: UsersIcon },
    { key: "reports", label: d.reports, Icon: ChartIcon },
    { key: "more", label: d.more, Icon: MoreIcon },
  ];

  return (
    <>
      <button
        onClick={onAdd}
        aria-label={d.addTransaction}
        className="tap fixed bottom-[72px] left-1/2 z-40 flex h-14 w-14 -translate-x-1/2 items-center justify-center rounded-full brand-grad text-white shadow-xl ring-4 ring-[#eef2f1]"
        style={{ marginLeft: "min(0px, 0px)" }}
      >
        <PlusIcon width={28} height={28} />
      </button>
      <nav className="fixed bottom-0 left-1/2 z-30 flex w-full max-w-[480px] -translate-x-1/2 items-stretch justify-around border-t border-slate-200 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur no-print">
        {items.map(({ key, label, Icon }, i) => {
          const isActive = active === key;
          return (
            <button
              key={key}
              onClick={() => onChange(key)}
              className={`tap flex flex-1 flex-col items-center gap-0.5 py-2.5 ${
                i === 1 ? "mr-6" : i === 2 ? "ml-6" : ""
              } ${isActive ? "text-teal-600" : "text-slate-400"}`}
            >
              <Icon width={23} height={23} strokeWidth={isActive ? 2.4 : 2} />
              <span className="text-[11px] font-semibold">{label}</span>
            </button>
          );
        })}
      </nav>
    </>
  );
}
