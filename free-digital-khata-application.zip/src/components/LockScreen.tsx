"use client";

import { useState } from "react";
import { useStore } from "@/lib/store";
import { Logo, LockIcon } from "./Icons";

export function LockScreen({ onUnlock }: { onUnlock: () => void }) {
  const { d, checkPin, business } = useStore();
  const [pin, setPin] = useState("");
  const [error, setError] = useState(false);

  const press = (n: string) => {
    if (pin.length >= 4) return;
    const next = pin + n;
    setPin(next);
    setError(false);
    if (next.length === 4) {
      setTimeout(() => {
        if (checkPin(next)) {
          onUnlock();
        } else {
          setError(true);
          setPin("");
        }
      }, 120);
    }
  };

  const del = () => setPin(pin.slice(0, -1));

  return (
    <div className="flex min-h-[100dvh] flex-col items-center justify-between bg-white px-8 py-12">
      <div className="mt-8 flex flex-col items-center text-center">
        <Logo size={56} />
        <h1 className="mt-4 text-xl font-extrabold text-slate-900">
          {business?.businessName || d.appName}
        </h1>
        <div className="mt-8 flex flex-col items-center">
          <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-teal-50 text-teal-600">
            <LockIcon width={26} />
          </div>
          <p className="font-semibold text-slate-600">{d.enterPin}</p>
          {error && (
            <p className="mt-1 text-sm font-medium text-rose-600">{d.wrongPin}</p>
          )}
        </div>
        <div className="mt-6 flex gap-3">
          {[0, 1, 2, 3].map((i) => (
            <span
              key={i}
              className={`h-3.5 w-3.5 rounded-full border-2 ${
                i < pin.length
                  ? "border-teal-600 bg-teal-600"
                  : "border-slate-300"
              }`}
            />
          ))}
        </div>
      </div>

      <div className="grid w-full max-w-xs grid-cols-3 gap-4">
        {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((n) => (
          <button
            key={n}
            onClick={() => press(n)}
            className="tap flex h-16 items-center justify-center rounded-2xl bg-slate-50 text-2xl font-bold text-slate-800"
          >
            {n}
          </button>
        ))}
        <span />
        <button
          onClick={() => press("0")}
          className="tap flex h-16 items-center justify-center rounded-2xl bg-slate-50 text-2xl font-bold text-slate-800"
        >
          0
        </button>
        <button
          onClick={del}
          className="tap flex h-16 items-center justify-center rounded-2xl text-lg font-bold text-slate-500"
        >
          ⌫
        </button>
      </div>
    </div>
  );
}
