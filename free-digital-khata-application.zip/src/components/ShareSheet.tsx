"use client";

import { useStore } from "@/lib/store";
import { Customer } from "@/lib/types";
import { Sheet } from "./ui";
import { DownloadIcon, PrintIcon, WhatsAppIcon, ShareIcon } from "./Icons";
import {
  buildStatementHTML,
  openPrint,
  downloadHTML,
  downloadCSV,
  csvEscape,
} from "@/lib/statement";
import { formatINR, formatFullDate } from "@/lib/format";

export function ShareSheet({
  open,
  onClose,
  customer,
}: {
  open: boolean;
  onClose: () => void;
  customer: Customer | null;
}) {
  const { d, business, transactionsOf } = useStore();

  if (!customer || !business) return null;
  const txns = transactionsOf(customer.id);

  const doPdf = () => {
    openPrint(buildStatementHTML(business, customer, txns, d));
  };
  const doDownload = () => {
    downloadHTML(
      buildStatementHTML(business, customer, txns, d),
      `${customer.name.replace(/\s+/g, "_")}_statement.html`
    );
  };
  const doCsv = () => {
    const header = ["Date", "Type", "Description", "Method", "Amount(₹)", "Note"];
    const lines = [header.map(csvEscape).join(",")];
    let running = 0;
    for (const t of txns) {
      running += t.type === "gave" ? t.amount : -t.amount;
      lines.push(
        [
          formatFullDate(t.date, d),
          t.type === "gave" ? d.youGave : d.youReceived,
          t.description,
          t.method,
          (t.amount / 100).toFixed(2),
          t.note,
        ]
          .map(csvEscape)
          .join(",")
      );
    }
    lines.push("");
    lines.push([csvEscape(d.closingBalance), csvEscape((running / 100).toFixed(2))].join(","));
    downloadCSV(lines.join("\n"), `${customer.name.replace(/\s+/g, "_")}_khata.csv`);
  };
  const shareWa = () => {
    const bal = txns.reduce(
      (a, t) => a + (t.type === "gave" ? t.amount : -t.amount),
      0
    );
    const text = encodeURIComponent(
      `${business.businessName}\n${d.customers}: ${customer.name}\n${
        d.closingBalance
      }: ${formatINR(Math.abs(bal))} ${bal >= 0 ? d.due : d.advance}\n\n${d.appName}`
    );
    window.open(`https://wa.me/?text=${text}`, "_blank");
  };

  return (
    <Sheet open={open} onClose={onClose} title={d.shareKhata}>
      <div className="mb-4 rounded-2xl bg-slate-50 p-4">
        <p className="font-bold text-slate-900">{customer.name}</p>
        <p className="text-sm text-slate-500">
          {txns.length} {d.entries}
        </p>
      </div>
      <div className="space-y-2.5">
        <Row onClick={doPdf} icon={<PrintIcon width={22} />} label={`${d.print} / ${d.downloadPdf}`} tint="bg-teal-50 text-teal-600" />
        <Row onClick={doDownload} icon={<DownloadIcon width={22} />} label={d.downloadPdf} tint="bg-indigo-50 text-indigo-600" />
        <Row onClick={doCsv} icon={<DownloadIcon width={22} />} label={d.exportCsv} tint="bg-amber-50 text-amber-600" />
        <Row onClick={shareWa} icon={<WhatsAppIcon width={22} height={22} />} label={d.sharePdf} tint="bg-emerald-50 text-emerald-600" />
      </div>
    </Sheet>
  );
}

function Row({
  onClick,
  icon,
  label,
  tint,
}: {
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
  tint: string;
}) {
  return (
    <button
      onClick={onClick}
      className="tap flex w-full items-center gap-3 rounded-2xl bg-white p-3.5 text-left shadow-sm ring-1 ring-slate-100"
    >
      <span className={`flex h-11 w-11 items-center justify-center rounded-full ${tint}`}>
        {icon}
      </span>
      <span className="flex-1 font-semibold text-slate-800">{label}</span>
      <ShareIcon width={18} className="text-slate-300" />
    </button>
  );
}
