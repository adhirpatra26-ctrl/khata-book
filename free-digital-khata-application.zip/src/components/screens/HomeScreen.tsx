"use client";

import { useMemo } from "react";
import { useStore } from "@/lib/store";
import { Customer } from "@/lib/types";
import { formatINR, startOfDay } from "@/lib/format";
import { Avatar } from "../ui";
import { Logo, ArrowUp, ArrowDown, PlusIcon, WhatsAppIcon, ChevronRight } from "../Icons";

export function HomeScreen({
  onOpenCustomer,
  onGive,
  onReceive,
  onAddCustomer,
  onRemind,
  onSeeAll,
}: {
  onOpenCustomer: (c: Customer) => void;
  onGive: () => void;
  onReceive: () => void;
  onAddCustomer: () => void;
  onRemind: (c: Customer) => void;
  onSeeAll: () => void;
}) {
  const { d, business, customers, transactions, balanceOf } = useStore();

  const greeting = useMemo(() => {
    const h = new Date().getHours();
    if (h < 12) return d.goodMorning;
    if (h < 17) return d.goodAfternoon;
    return d.goodEvening;
  }, [d]);

  const stats = useMemo(() => {
    const today = startOfDay(Date.now());
    let toReceive = 0;
    for (const c of customers) {
      const b = balanceOf(c.id);
      if (b > 0) toReceive += b;
    }
    let todaySales = 0;
    let todayReceived = 0;
    for (const t of transactions) {
      if (startOfDay(t.date) === today) {
        if (t.type === "gave") todaySales += t.amount;
        else todayReceived += t.amount;
      }
    }
    return { toReceive, todaySales, todayReceived };
  }, [customers, transactions, balanceOf]);

  const pending = useMemo(() => {
    return customers
      .map((c) => ({ c, bal: balanceOf(c.id) }))
      .filter((x) => x.bal > 0)
      .sort((a, b) => b.bal - a.bal);
  }, [customers, balanceOf]);

  return (
    <div className="pb-32">
      {/* Header */}
      <div className="brand-grad px-5 pb-16 pt-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-white/80">{greeting} 👋</p>
            <h1 className="text-xl font-extrabold">{business?.businessName}</h1>
          </div>
          <div className="rounded-2xl bg-white/15 p-1.5">
            <Logo size={34} />
          </div>
        </div>
      </div>

      {/* Summary cards */}
      <div className="-mt-11 px-5">
        <div className="rounded-3xl bg-white p-4 shadow-lg shadow-teal-900/5">
          <p className="text-sm font-semibold text-slate-500">{d.totalToReceive}</p>
          <p className="mt-1 text-4xl font-extrabold text-teal-700">
            {formatINR(stats.toReceive)}
          </p>
          <div className="mt-4 grid grid-cols-3 gap-2 border-t border-slate-100 pt-4">
            <MiniStat label={d.todaysSales} value={formatINR(stats.todaySales)} color="text-rose-600" />
            <MiniStat label={d.todaysReceived} value={formatINR(stats.todayReceived)} color="text-emerald-600" />
            <MiniStat label={d.customers} value={String(customers.length)} color="text-slate-800" />
          </div>
        </div>
      </div>

      {/* Quick actions */}
      <div className="px-5 pt-6">
        <p className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-400">
          {d.quickActions}
        </p>
        <div className="grid grid-cols-3 gap-3">
          <QuickAction
            onClick={onReceive}
            label={d.receivePayment}
            icon={<ArrowDown width={22} />}
            tint="bg-emerald-50 text-emerald-600"
          />
          <QuickAction
            onClick={onGive}
            label={d.giveCredit}
            icon={<ArrowUp width={22} />}
            tint="bg-rose-50 text-rose-600"
          />
          <QuickAction
            onClick={onAddCustomer}
            label={d.addCustomer}
            icon={<PlusIcon width={22} />}
            tint="bg-teal-50 text-teal-600"
          />
        </div>
      </div>

      {/* Pending customers */}
      <div className="px-5 pt-7">
        <div className="mb-3 flex items-center justify-between">
          <p className="text-sm font-bold uppercase tracking-wide text-slate-400">
            {d.pendingCustomers}
          </p>
          {pending.length > 0 && (
            <button
              onClick={onSeeAll}
              className="tap flex items-center text-sm font-semibold text-teal-600"
            >
              {d.customers} <ChevronRight width={16} />
            </button>
          )}
        </div>

        {pending.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-200 bg-white py-10 text-center">
            <p className="text-3xl">🎉</p>
            <p className="mt-2 font-semibold text-slate-600">{d.noPending}</p>
            <p className="text-sm text-slate-400">{d.allSettled}</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {pending.slice(0, 6).map(({ c, bal }) => (
              <div
                key={c.id}
                className="flex items-center gap-3 rounded-2xl bg-white p-3 shadow-sm"
              >
                <button
                  onClick={() => onOpenCustomer(c)}
                  className="tap flex min-w-0 flex-1 items-center gap-3 text-left"
                >
                  <Avatar name={c.name} />
                  <div className="min-w-0">
                    <p className="truncate font-bold text-slate-900">{c.name}</p>
                    <p className="text-sm font-semibold text-rose-600">
                      {formatINR(bal)} {d.due}
                    </p>
                  </div>
                </button>
                <button
                  onClick={() => onRemind(c)}
                  className="tap flex shrink-0 items-center gap-1.5 rounded-xl bg-[#25D366] px-3.5 py-2.5 text-sm font-bold text-white"
                >
                  <WhatsAppIcon width={17} height={17} />
                  {d.remind}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function MiniStat({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div>
      <p className="truncate text-[11px] font-medium text-slate-400">{label}</p>
      <p className={`mt-0.5 truncate text-base font-extrabold ${color}`}>{value}</p>
    </div>
  );
}

function QuickAction({
  onClick,
  label,
  icon,
  tint,
}: {
  onClick: () => void;
  label: string;
  icon: React.ReactNode;
  tint: string;
}) {
  return (
    <button
      onClick={onClick}
      className="tap flex flex-col items-center gap-2 rounded-2xl bg-white p-3 shadow-sm"
    >
      <span className={`flex h-11 w-11 items-center justify-center rounded-full ${tint}`}>
        {icon}
      </span>
      <span className="text-center text-xs font-bold leading-tight text-slate-700">
        {label}
      </span>
    </button>
  );
}
