"use client";

import { useRef, useState } from "react";
import { useStore } from "@/lib/store";
import { Lang } from "@/lib/types";
import { languageNames } from "@/lib/i18n";
import { Sheet, Field, inputCls, Confirm } from "../ui";
import {
  Logo,
  GlobeIcon,
  LockIcon,
  CloudIcon,
  InfoIcon,
  ChevronRight,
  DownloadIcon,
  CheckIcon,
} from "../Icons";
import { downloadCSV, csvEscape } from "@/lib/statement";
import { formatFullDate } from "@/lib/format";

export function MoreScreen({ onToast }: { onToast: (m: string) => void }) {
  const {
    d,
    lang,
    setLang,
    business,
    updateBusiness,
    hasPin,
    setPin,
    removePin,
    autoLock,
    setAutoLock,
    exportJSON,
    importJSON,
    customers,
    transactions,
    resetAll,
  } = useStore();

  const [langOpen, setLangOpen] = useState(false);
  const [pinOpen, setPinOpen] = useState(false);
  const [bizOpen, setBizOpen] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const doExport = () => {
    const json = exportJSON();
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `hisabgo_backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    onToast(d.exportData);
  };

  const doImport = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const ok = importJSON(String(reader.result));
      onToast(ok ? d.importData + " ✓" : "Invalid file");
    };
    reader.readAsText(file);
  };

  const doCsvAll = () => {
    const header = ["Customer", "Mobile", "Date", "Type", "Description", "Method", "Amount(₹)"];
    const lines = [header.map(csvEscape).join(",")];
    const cmap = new Map(customers.map((c) => [c.id, c]));
    for (const t of [...transactions].sort((a, b) => a.date - b.date)) {
      const c = cmap.get(t.customerId);
      lines.push(
        [
          c?.name || "",
          c?.mobile || "",
          formatFullDate(t.date, d),
          t.type === "gave" ? d.youGave : d.youReceived,
          t.description,
          t.method,
          (t.amount / 100).toFixed(2),
        ]
          .map(csvEscape)
          .join(",")
      );
    }
    downloadCSV(lines.join("\n"), `hisabgo_all_${new Date().toISOString().slice(0, 10)}.csv`);
    onToast(d.exportCsv);
  };

  return (
    <div className="pb-32">
      <div className="brand-grad px-5 pb-16 pt-6 text-white">
        <div className="flex items-center gap-3">
          <div className="rounded-2xl bg-white/15 p-1.5">
            <Logo size={40} />
          </div>
          <div className="min-w-0">
            <h1 className="truncate text-lg font-extrabold">{business?.businessName}</h1>
            <p className="text-sm text-white/80">{business?.ownerName} · {business?.mobile || "—"}</p>
          </div>
        </div>
      </div>

      <div className="-mt-11 px-5">
        <div className="rounded-2xl bg-white p-4 text-center shadow-lg">
          <div className="mb-1 flex items-center justify-center gap-2">
            <span className="rounded-full bg-teal-600 px-2.5 py-0.5 text-xs font-extrabold text-white">
              {d.free}
            </span>
          </div>
          <p className="text-sm text-slate-500">{d.freeMessage}</p>
        </div>
      </div>

      <div className="px-5 pt-5">
        <Section title={d.settings}>
          <Item
            icon={<GlobeIcon width={20} />}
            tint="bg-indigo-50 text-indigo-600"
            label={d.language}
            value={languageNames[lang]}
            onClick={() => setLangOpen(true)}
          />
          <Item
            icon={<InfoIcon width={20} />}
            tint="bg-sky-50 text-sky-600"
            label={d.businessName}
            value={business?.businessName}
            onClick={() => setBizOpen(true)}
          />
        </Section>

        <Section title={d.security}>
          <Item
            icon={<LockIcon width={20} />}
            tint="bg-rose-50 text-rose-600"
            label={d.pinLock}
            value={hasPin ? "••••" : d.setPin}
            onClick={() => setPinOpen(true)}
          />
          <ToggleItem
            icon={<LockIcon width={20} />}
            tint="bg-amber-50 text-amber-600"
            label={d.autoLock}
            checked={autoLock}
            disabled={!hasPin}
            onChange={setAutoLock}
          />
        </Section>

        <Section title={d.backupExport}>
          <Item
            icon={<CloudIcon width={20} />}
            tint="bg-emerald-50 text-emerald-600"
            label={d.exportData}
            onClick={doExport}
          />
          <Item
            icon={<DownloadIcon width={20} />}
            tint="bg-teal-50 text-teal-600"
            label={d.importData}
            onClick={() => fileRef.current?.click()}
          />
          <Item
            icon={<DownloadIcon width={20} />}
            tint="bg-purple-50 text-purple-600"
            label={d.exportCsv}
            onClick={doCsvAll}
          />
        </Section>

        <Section title={d.about}>
          <div className="rounded-2xl bg-white p-4 text-center shadow-sm">
            <div className="flex justify-center">
              <Logo size={44} />
            </div>
            <p className="mt-2 font-extrabold text-slate-800">{d.appName}</p>
            <p className="text-sm text-slate-400">{d.tagline}</p>
            <p className="mt-1 text-xs text-slate-300">v1.0 · {d.free}</p>
            <button
              onClick={() => setResetOpen(true)}
              className="tap mt-4 text-sm font-semibold text-rose-500"
            >
              Reset all data
            </button>
          </div>
        </Section>
      </div>

      <input
        ref={fileRef}
        type="file"
        accept="application/json,.json"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) doImport(f);
          e.target.value = "";
        }}
      />

      {/* Language sheet */}
      <Sheet open={langOpen} onClose={() => setLangOpen(false)} title={d.language}>
        <div className="space-y-2">
          {(Object.keys(languageNames) as Lang[]).map((l) => (
            <button
              key={l}
              onClick={() => {
                setLang(l);
                setLangOpen(false);
              }}
              className={`tap flex w-full items-center justify-between rounded-2xl border p-4 text-left ${
                lang === l ? "border-teal-500 bg-teal-50" : "border-slate-200 bg-white"
              }`}
            >
              <span className="text-lg font-bold text-slate-800">
                {languageNames[l]}
              </span>
              {lang === l && <CheckIcon width={22} className="text-teal-600" />}
            </button>
          ))}
        </div>
      </Sheet>

      <PinSheet
        open={pinOpen}
        onClose={() => setPinOpen(false)}
        hasPin={hasPin}
        onSet={(p) => {
          setPin(p);
          setPinOpen(false);
          onToast(d.setPin + " ✓");
        }}
        onRemove={() => {
          removePin();
          setAutoLock(false);
          setPinOpen(false);
          onToast(d.removePin + " ✓");
        }}
      />

      <BizSheet
        open={bizOpen}
        onClose={() => setBizOpen(false)}
        onSave={(v) => {
          updateBusiness(v);
          setBizOpen(false);
          onToast(d.save + " ✓");
        }}
      />

      <Confirm
        open={resetOpen}
        title="Delete ALL data permanently?"
        confirmLabel={d.delete}
        cancelLabel={d.cancel}
        danger
        onConfirm={() => {
          resetAll();
          setResetOpen(false);
        }}
        onCancel={() => setResetOpen(false)}
      />
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mb-5">
      <p className="mb-2 px-1 text-xs font-bold uppercase tracking-wide text-slate-400">
        {title}
      </p>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

function Item({
  icon,
  tint,
  label,
  value,
  onClick,
}: {
  icon: React.ReactNode;
  tint: string;
  label: string;
  value?: string;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="tap flex w-full items-center gap-3 rounded-2xl bg-white p-3.5 text-left shadow-sm"
    >
      <span className={`flex h-10 w-10 items-center justify-center rounded-full ${tint}`}>
        {icon}
      </span>
      <span className="flex-1 font-semibold text-slate-800">{label}</span>
      {value && <span className="max-w-[40%] truncate text-sm text-slate-400">{value}</span>}
      <ChevronRight width={18} className="text-slate-300" />
    </button>
  );
}

function ToggleItem({
  icon,
  tint,
  label,
  checked,
  disabled,
  onChange,
}: {
  icon: React.ReactNode;
  tint: string;
  label: string;
  checked: boolean;
  disabled?: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div
      className={`flex w-full items-center gap-3 rounded-2xl bg-white p-3.5 shadow-sm ${
        disabled ? "opacity-50" : ""
      }`}
    >
      <span className={`flex h-10 w-10 items-center justify-center rounded-full ${tint}`}>
        {icon}
      </span>
      <span className="flex-1 font-semibold text-slate-800">{label}</span>
      <button
        disabled={disabled}
        onClick={() => onChange(!checked)}
        className={`tap relative h-7 w-12 rounded-full transition-colors ${
          checked ? "bg-teal-600" : "bg-slate-200"
        }`}
      >
        <span
          className={`absolute top-1 h-5 w-5 rounded-full bg-white transition-all ${
            checked ? "left-6" : "left-1"
          }`}
        />
      </button>
    </div>
  );
}

function PinSheet({
  open,
  onClose,
  hasPin,
  onSet,
  onRemove,
}: {
  open: boolean;
  onClose: () => void;
  hasPin: boolean;
  onSet: (p: string) => void;
  onRemove: () => void;
}) {
  const { d } = useStore();
  const [p1, setP1] = useState("");
  const [p2, setP2] = useState("");
  const [err, setErr] = useState("");

  const save = () => {
    if (p1.length !== 4) {
      setErr(d.invalidAmount);
      return;
    }
    if (p1 !== p2) {
      setErr(d.pinMismatch);
      return;
    }
    onSet(p1);
    setP1("");
    setP2("");
    setErr("");
  };

  return (
    <Sheet open={open} onClose={onClose} title={hasPin ? d.changePin : d.setPin}>
      <Field label={d.setPin}>
        <input
          inputMode="numeric"
          maxLength={4}
          value={p1}
          onChange={(e) => {
            setP1(e.target.value.replace(/[^0-9]/g, ""));
            setErr("");
          }}
          placeholder="4-digit PIN"
          className={inputCls + " text-center text-2xl tracking-[0.5em]"}
        />
      </Field>
      <Field label={d.confirmPin}>
        <input
          inputMode="numeric"
          maxLength={4}
          value={p2}
          onChange={(e) => {
            setP2(e.target.value.replace(/[^0-9]/g, ""));
            setErr("");
          }}
          placeholder="••••"
          className={inputCls + " text-center text-2xl tracking-[0.5em]"}
        />
      </Field>
      {err && <p className="mb-2 text-sm font-medium text-rose-600">{err}</p>}
      <button
        onClick={save}
        className="tap mt-2 w-full rounded-2xl bg-teal-600 py-4 font-bold text-white"
      >
        {d.save}
      </button>
      {hasPin && (
        <button
          onClick={onRemove}
          className="tap mt-2 w-full rounded-2xl bg-rose-50 py-3.5 font-bold text-rose-600"
        >
          {d.removePin}
        </button>
      )}
    </Sheet>
  );
}

function BizSheet({
  open,
  onClose,
  onSave,
}: {
  open: boolean;
  onClose: () => void;
  onSave: (v: { businessName: string; ownerName: string; mobile: string }) => void;
}) {
  const { d, business } = useStore();
  const [name, setName] = useState(business?.businessName || "");
  const [owner, setOwner] = useState(business?.ownerName || "");
  const [mobile, setMobile] = useState(business?.mobile || "");

  return (
    <Sheet open={open} onClose={onClose} title={d.businessName}>
      <Field label={d.businessName}>
        <input value={name} onChange={(e) => setName(e.target.value)} className={inputCls} />
      </Field>
      <Field label={d.ownerName}>
        <input value={owner} onChange={(e) => setOwner(e.target.value)} className={inputCls} />
      </Field>
      <Field label={d.mobile}>
        <input
          inputMode="tel"
          value={mobile}
          onChange={(e) => setMobile(e.target.value.replace(/[^0-9+]/g, ""))}
          className={inputCls}
        />
      </Field>
      <button
        onClick={() =>
          onSave({ businessName: name.trim(), ownerName: owner.trim(), mobile: mobile.trim() })
        }
        className="tap mt-2 w-full rounded-2xl bg-teal-600 py-4 font-bold text-white"
      >
        {d.save}
      </button>
    </Sheet>
  );
}
