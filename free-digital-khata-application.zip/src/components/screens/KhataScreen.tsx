"use client";

import { useMemo, useState } from "react";
import { useStore } from "@/lib/store";
import { Customer, TxType } from "@/lib/types";
import { formatINR, formatDate, formatTime } from "@/lib/format";
import { Avatar, Confirm } from "../ui";
import {
  BackIcon,
  ArrowUp,
  ArrowDown,
  WhatsAppIcon,
  ShareIcon,
  TrashIcon,
  EditIcon,
  PhoneIcon,
} from "../Icons";

export function KhataScreen({
  customer,
  onBack,
  onAddTx,
  onRemind,
  onShare,
  onEdit,
}: {
  customer: Customer;
  onBack: () => void;
  onAddTx: (type: TxType) => void;
  onRemind: () => void;
  onShare: () => void;
  onEdit: () => void;
}) {
  const { d, transactionsOf, deleteTransaction } = useStore();
  const [delId, setDelId] = useState<string | null>(null);

  const txns = useMemo(() => transactionsOf(customer.id), [transactionsOf, customer.id]);

  const { balance, rows } = useMemo(() => {
    let running = 0;
    const rows = txns.map((t) => {
      running += t.type === "gave" ? t.amount : -t.amount;
      return { t, running };
    });
    return { balance: running, rows: rows.reverse() };
  }, [txns]);

  return (
    <div className="pb-32">
      {/* Header */}
      <div className="brand-grad px-4 pb-6 pt-4 text-white">
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="tap -ml-1 rounded-full p-1.5">
            <BackIcon width={24} />
          </button>
          <div className="flex gap-1">
            {customer.mobile && (
              <a
                href={`tel:${customer.mobile}`}
                className="tap rounded-full p-2 text-white/90"
              >
                <PhoneIcon width={20} />
              </a>
            )}
            <button onClick={onEdit} className="tap rounded-full p-2 text-white/90">
              <EditIcon width={20} />
            </button>
            <button onClick={onShare} className="tap rounded-full p-2 text-white/90">
              <ShareIcon width={20} />
            </button>
          </div>
        </div>

        <div className="mt-1 flex items-center gap-3">
          <Avatar name={customer.name} size={48} />
          <div className="min-w-0">
            <h1 className="truncate text-xl font-extrabold">{customer.name}</h1>
            <p className="text-sm text-white/80">{customer.mobile || "—"}</p>
          </div>
        </div>

        <div className="mt-5 rounded-2xl bg-white/15 p-4 text-center">
          <p className="text-sm font-medium text-white/85">
            {balance > 0 ? d.totalDue : balance < 0 ? d.advance : d.settled}
          </p>
          <p className="text-4xl font-extrabold">{formatINR(Math.abs(balance))}</p>
        </div>
      </div>

      {/* Big action buttons */}
      <div className="grid grid-cols-2 gap-3 px-4 pt-4">
        <button
          onClick={() => onAddTx("gave")}
          className="tap flex items-center justify-center gap-2 rounded-2xl bg-rose-500 py-4 font-bold text-white shadow-lg shadow-rose-500/20"
        >
          <ArrowUp width={20} /> {d.youGave}
        </button>
        <button
          onClick={() => onAddTx("received")}
          className="tap flex items-center justify-center gap-2 rounded-2xl bg-emerald-500 py-4 font-bold text-white shadow-lg shadow-emerald-500/20"
        >
          <ArrowDown width={20} /> {d.youReceived}
        </button>
      </div>

      {balance > 0 && (
        <div className="px-4 pt-3">
          <button
            onClick={onRemind}
            className="tap flex w-full items-center justify-center gap-2 rounded-2xl border border-[#25D366]/40 bg-[#25D366]/10 py-3 font-bold text-[#128C4B]"
          >
            <WhatsAppIcon width={19} height={19} /> {d.remind}
          </button>
        </div>
      )}

      {/* Transactions */}
      <div className="px-4 pt-5">
        {rows.length === 0 ? (
          <div className="mt-8 flex flex-col items-center rounded-2xl border border-dashed border-slate-200 bg-white py-12 text-center">
            <p className="text-3xl">🧾</p>
            <p className="mt-2 font-semibold text-slate-600">{d.noTransactions}</p>
            <button
              onClick={() => onAddTx("gave")}
              className="tap mt-4 rounded-xl bg-teal-600 px-5 py-2.5 text-sm font-bold text-white"
            >
              + {d.addTransaction}
            </button>
          </div>
        ) : (
          <>
            <div className="mb-2 flex justify-between px-1 text-[11px] font-bold uppercase tracking-wide text-slate-400">
              <span>{d.date}</span>
              <span>{d.balanceDue}</span>
            </div>
            <div className="space-y-2">
              {rows.map(({ t, running }) => {
                const isGave = t.type === "gave";
                return (
                  <div
                    key={t.id}
                    className="rounded-2xl bg-white p-3.5 shadow-sm"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <p className="font-semibold text-slate-800">
                          {t.description ||
                            (isGave ? d.giveCredit : d.receivePayment)}
                        </p>
                        <p className="mt-0.5 text-xs text-slate-400">
                          {formatDate(t.date, d)} · {formatTime(t.createdAt)}
                          {t.method &&
                            ` · ${
                              t.method === "cash"
                                ? d.cash
                                : t.method === "upi"
                                ? d.upi
                                : t.method === "bank"
                                ? d.bankTransfer
                                : d.other
                            }`}
                        </p>
                        {t.note && (
                          <p className="mt-1 text-xs italic text-slate-400">
                            {t.note}
                          </p>
                        )}
                      </div>
                      <div className="text-right">
                        <span
                          className={`inline-block rounded-lg px-2.5 py-1 text-sm font-bold ${
                            isGave
                              ? "bg-rose-50 text-rose-600"
                              : "bg-emerald-50 text-emerald-600"
                          }`}
                        >
                          {isGave ? "+" : "-"}
                          {formatINR(t.amount)}
                        </span>
                        <p className="mt-1 text-[11px] font-medium text-slate-400">
                          {formatINR(Math.abs(running))}{" "}
                          {running >= 0 ? d.due : d.advance}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 flex justify-end border-t border-slate-50 pt-2">
                      <button
                        onClick={() => setDelId(t.id)}
                        className="tap flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-semibold text-slate-400"
                      >
                        <TrashIcon width={14} /> {d.delete}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}
      </div>

      <Confirm
        open={!!delId}
        title={d.deleteTxConfirm}
        confirmLabel={d.delete}
        cancelLabel={d.cancel}
        danger
        onConfirm={() => {
          if (delId) deleteTransaction(delId);
          setDelId(null);
        }}
        onCancel={() => setDelId(null)}
      />
    </div>
  );
}
