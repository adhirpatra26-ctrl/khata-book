"use client";

import { useMemo, useState } from "react";
import { useStore } from "@/lib/store";
import { Customer } from "@/lib/types";
import { formatINR } from "@/lib/format";
import { Avatar } from "../ui";
import { SearchIcon, PlusIcon, UsersIcon } from "../Icons";

export function CustomersScreen({
  onOpenCustomer,
  onAddCustomer,
}: {
  onOpenCustomer: (c: Customer) => void;
  onAddCustomer: () => void;
}) {
  const { d, customers, balanceOf } = useStore();
  const [q, setQ] = useState("");

  const list = useMemo(() => {
    const query = q.trim().toLowerCase();
    return customers
      .filter(
        (c) =>
          !query ||
          c.name.toLowerCase().includes(query) ||
          c.mobile.includes(query)
      )
      .map((c) => ({ c, bal: balanceOf(c.id) }))
      .sort((a, b) => b.bal - a.bal);
  }, [customers, q, balanceOf]);

  const totalReceive = list.reduce((a, x) => a + (x.bal > 0 ? x.bal : 0), 0);

  return (
    <div className="pb-32">
      {/* Header */}
      <div className="brand-grad px-5 pb-5 pt-6 text-white">
        <h1 className="text-xl font-extrabold">{d.customers}</h1>
        <p className="text-sm text-white/80">
          {customers.length} {d.customers.toLowerCase()} · {d.totalToReceive}:{" "}
          <b className="text-white">{formatINR(totalReceive)}</b>
        </p>
        <div className="mt-4 flex items-center gap-2 rounded-2xl bg-white px-4 py-3 shadow-sm">
          <SearchIcon width={20} className="text-slate-400" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={d.searchCustomer}
            className="w-full bg-transparent text-slate-900 outline-none placeholder:text-slate-400"
          />
        </div>
      </div>

      <div className="px-5 pt-5">
        {list.length === 0 ? (
          <div className="mt-10 flex flex-col items-center text-center">
            <div className="mb-4 flex h-20 w-20 items-center justify-center rounded-3xl bg-teal-50 text-teal-500">
              <UsersIcon width={40} />
            </div>
            <p className="font-bold text-slate-700">{d.noCustomers}</p>
            <p className="mt-1 text-sm text-slate-400">{d.addFirstCustomer}</p>
            <button
              onClick={onAddCustomer}
              className="tap mt-5 flex items-center gap-1.5 rounded-2xl bg-teal-600 px-6 py-3 font-bold text-white shadow-lg"
            >
              <PlusIcon width={18} /> {d.addCustomer}
            </button>
          </div>
        ) : (
          <div className="space-y-2.5">
            {list.map(({ c, bal }) => (
              <button
                key={c.id}
                onClick={() => onOpenCustomer(c)}
                className="tap flex w-full items-center gap-3 rounded-2xl bg-white p-3.5 text-left shadow-sm"
              >
                <Avatar name={c.name} size={46} />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-bold text-slate-900">{c.name}</p>
                  <p className="text-sm text-slate-400">{c.mobile || "—"}</p>
                </div>
                <div className="text-right">
                  {bal === 0 ? (
                    <span className="text-sm font-semibold text-slate-400">
                      {d.settled}
                    </span>
                  ) : (
                    <>
                      <p
                        className={`text-base font-extrabold ${
                          bal > 0 ? "text-rose-600" : "text-emerald-600"
                        }`}
                      >
                        {formatINR(Math.abs(bal))}
                      </p>
                      <p className="text-[11px] font-semibold text-slate-400">
                        {bal > 0 ? d.due : d.advance}
                      </p>
                    </>
                  )}
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
