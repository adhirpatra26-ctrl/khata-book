"use client";

import { useMemo, useState } from "react";
import { useStore } from "@/lib/store";
import { formatINR, startOfDay, dateInputValue } from "@/lib/format";
import { ArrowUp, ArrowDown, WalletIcon } from "../Icons";

type Range = "today" | "week" | "month" | "custom";

export function ReportsScreen() {
  const { d, transactions, customers, balanceOf } = useStore();
  const [range, setRange] = useState<Range>("today");
  const [from, setFrom] = useState(dateInputValue(Date.now() - 6 * 864e5));
  const [to, setTo] = useState(dateInputValue(Date.now()));

  const { start, end } = useMemo(() => {
    const now = Date.now();
    const todayStart = startOfDay(now);
    if (range === "today") return { start: todayStart, end: now + 864e5 };
    if (range === "week") return { start: todayStart - 6 * 864e5, end: now + 864e5 };
    if (range === "month") {
      const dd = new Date();
      return { start: new Date(dd.getFullYear(), dd.getMonth(), 1).getTime(), end: now + 864e5 };
    }
    const f = new Date(from);
    f.setHours(0, 0, 0, 0);
    const t = new Date(to);
    t.setHours(23, 59, 59, 999);
    return { start: f.getTime(), end: t.getTime() };
  }, [range, from, to]);

  const report = useMemo(() => {
    const inRange = transactions.filter((t) => t.date >= start && t.date <= end);
    const given = inRange.filter((t) => t.type === "gave").reduce((a, t) => a + t.amount, 0);
    const received = inRange.filter((t) => t.type === "received").reduce((a, t) => a + t.amount, 0);
    let outstanding = 0;
    for (const c of customers) {
      const b = balanceOf(c.id);
      if (b > 0) outstanding += b;
    }
    // Customer-wise due (top)
    const dues = customers
      .map((c) => ({ c, bal: balanceOf(c.id) }))
      .filter((x) => x.bal > 0)
      .sort((a, b) => b.bal - a.bal)
      .slice(0, 8);
    const maxDue = dues[0]?.bal || 1;

    // Daily bars for week view
    return { given, received, outstanding, dues, maxDue, count: inRange.length };
  }, [transactions, customers, start, end, balanceOf]);

  const maxBar = Math.max(report.given, report.received, 1);

  return (
    <div className="pb-32">
      <div className="brand-grad px-5 pb-5 pt-6 text-white">
        <h1 className="text-xl font-extrabold">{d.reports}</h1>
        <p className="text-sm text-white/80">
          {report.count} {d.entries}
        </p>
      </div>

      {/* Range tabs */}
      <div className="px-5 pt-4">
        <div className="grid grid-cols-4 gap-2 rounded-2xl bg-slate-100 p-1.5">
          {(
            [
              ["today", d.today],
              ["week", d.thisWeek],
              ["month", d.thisMonth],
              ["custom", d.customRange],
            ] as [Range, string][]
          ).map(([r, label]) => (
            <button
              key={r}
              onClick={() => setRange(r)}
              className={`tap rounded-xl py-2 text-xs font-bold ${
                range === r ? "bg-white text-teal-700 shadow" : "text-slate-500"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {range === "custom" && (
          <div className="mt-3 flex items-center gap-2">
            <input
              type="date"
              value={from}
              onChange={(e) => setFrom(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none"
            />
            <span className="text-slate-400">→</span>
            <input
              type="date"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none"
            />
          </div>
        )}
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 gap-3 px-5 pt-4">
        <Card
          label={d.sales}
          sub={d.totalGiven}
          value={formatINR(report.given)}
          tint="text-rose-600"
          bg="bg-rose-50"
          icon={<ArrowUp width={18} />}
        />
        <Card
          label={d.totalReceived}
          sub={d.receivePayment}
          value={formatINR(report.received)}
          tint="text-emerald-600"
          bg="bg-emerald-50"
          icon={<ArrowDown width={18} />}
        />
      </div>
      <div className="px-5 pt-3">
        <div className="rounded-2xl bg-white p-4 shadow-sm">
          <div className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-teal-50 text-teal-600">
              <WalletIcon width={18} />
            </span>
            <div>
              <p className="text-xs font-medium text-slate-400">{d.totalOutstanding}</p>
              <p className="text-2xl font-extrabold text-teal-700">
                {formatINR(report.outstanding)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Bar comparison */}
      <div className="px-5 pt-4">
        <div className="rounded-2xl bg-white p-4 shadow-sm">
          <p className="mb-3 text-sm font-bold text-slate-600">
            {d.totalGiven} vs {d.totalReceived}
          </p>
          <BarRow label={d.totalGiven} value={report.given} max={maxBar} color="bg-rose-500" text="text-rose-600" />
          <BarRow label={d.totalReceived} value={report.received} max={maxBar} color="bg-emerald-500" text="text-emerald-600" />
        </div>
      </div>

      {/* Customer-wise due */}
      <div className="px-5 pt-4">
        <p className="mb-2 text-sm font-bold uppercase tracking-wide text-slate-400">
          {d.customers} · {d.totalOutstanding}
        </p>
        {report.dues.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-200 bg-white py-8 text-center text-sm text-slate-400">
            {d.noPending}
          </div>
        ) : (
          <div className="space-y-2.5 rounded-2xl bg-white p-4 shadow-sm">
            {report.dues.map(({ c, bal }) => (
              <div key={c.id}>
                <div className="mb-1 flex justify-between text-sm">
                  <span className="truncate font-semibold text-slate-700">{c.name}</span>
                  <span className="font-bold text-rose-600">{formatINR(bal)}</span>
                </div>
                <div className="h-2 w-full rounded-full bg-slate-100">
                  <div
                    className="h-2 rounded-full bg-teal-500"
                    style={{ width: `${Math.max(6, (bal / report.maxDue) * 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function Card({
  label,
  sub,
  value,
  tint,
  bg,
  icon,
}: {
  label: string;
  sub: string;
  value: string;
  tint: string;
  bg: string;
  icon: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl bg-white p-4 shadow-sm">
      <span className={`inline-flex h-8 w-8 items-center justify-center rounded-full ${bg} ${tint}`}>
        {icon}
      </span>
      <p className="mt-2 text-xs font-medium text-slate-400">{label}</p>
      <p className={`text-xl font-extrabold ${tint}`}>{value}</p>
    </div>
  );
}

function BarRow({
  label,
  value,
  max,
  color,
  text,
}: {
  label: string;
  value: number;
  max: number;
  color: string;
  text: string;
}) {
  return (
    <div className="mb-3 last:mb-0">
      <div className="mb-1 flex justify-between text-sm">
        <span className="font-semibold text-slate-600">{label}</span>
        <span className={`font-bold ${text}`}>{formatINR(value)}</span>
      </div>
      <div className="h-3 w-full rounded-full bg-slate-100">
        <div
          className={`h-3 rounded-full ${color} transition-all`}
          style={{ width: `${Math.max(3, (value / max) * 100)}%` }}
        />
      </div>
    </div>
  );
}
