"use client";

import { ReactNode, useEffect } from "react";

export function Sheet({
  open,
  onClose,
  children,
  title,
}: {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  title?: string;
}) {
  useEffect(() => {
    if (open) {
      document.body.style.overflow = "hidden";
      return () => {
        document.body.style.overflow = "";
      };
    }
  }, [open]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      <div
        className="absolute inset-0 bg-slate-900/50 fade-in"
        onClick={onClose}
      />
      <div className="relative w-full max-w-[480px] max-h-[92dvh] overflow-y-auto no-scrollbar rounded-t-3xl bg-white sheet-anim">
        <div className="sticky top-0 z-10 flex items-center justify-center bg-white pt-3 pb-1">
          <div className="h-1.5 w-11 rounded-full bg-slate-200" />
        </div>
        {title && (
          <div className="px-5 pb-2">
            <h2 className="text-lg font-bold text-slate-900">{title}</h2>
          </div>
        )}
        <div className="px-5 pb-8">{children}</div>
      </div>
    </div>
  );
}

export function Confirm({
  open,
  title,
  confirmLabel,
  cancelLabel,
  danger,
  onConfirm,
  onCancel,
}: {
  open: boolean;
  title: string;
  confirmLabel: string;
  cancelLabel: string;
  danger?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center px-8">
      <div className="absolute inset-0 bg-slate-900/50 fade-in" onClick={onCancel} />
      <div className="relative w-full max-w-xs rounded-2xl bg-white p-5 text-center shadow-xl fade-in">
        <p className="mb-5 text-base font-semibold text-slate-800">{title}</p>
        <div className="flex gap-3">
          <button
            onClick={onCancel}
            className="tap flex-1 rounded-xl bg-slate-100 py-3 font-semibold text-slate-600"
          >
            {cancelLabel}
          </button>
          <button
            onClick={onConfirm}
            className={`tap flex-1 rounded-xl py-3 font-semibold text-white ${
              danger ? "bg-rose-600" : "bg-teal-600"
            }`}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="mb-3 block">
      <span className="mb-1.5 block text-sm font-semibold text-slate-600">
        {label}
      </span>
      {children}
    </label>
  );
}

export const inputCls =
  "w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none focus:border-teal-500 focus:bg-white transition-colors";

export function Toast({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <div className="fixed bottom-24 left-1/2 z-[70] -translate-x-1/2 fade-in">
      <div className="flex items-center gap-2 rounded-full bg-slate-900 px-5 py-2.5 text-sm font-medium text-white shadow-lg">
        {message}
      </div>
    </div>
  );
}

export function Avatar({ name, size = 44 }: { name: string; size?: number }) {
  const colors = [
    "#0e9488",
    "#6366f1",
    "#f59e0b",
    "#ec4899",
    "#0ea5e9",
    "#8b5cf6",
    "#ef4444",
    "#10b981",
  ];
  const idx =
    name.split("").reduce((a, c) => a + c.charCodeAt(0), 0) % colors.length;
  const initials = name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() || "")
    .join("");
  return (
    <div
      className="flex shrink-0 items-center justify-center rounded-full font-bold text-white"
      style={{
        width: size,
        height: size,
        background: colors[idx],
        fontSize: size * 0.36,
      }}
    >
      {initials || "?"}
    </div>
  );
}
